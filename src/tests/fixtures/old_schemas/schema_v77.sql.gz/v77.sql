SET FOREIGN_KEY_CHECKS = 0;
CREATE TABLE IF NOT EXISTS schema_migrations (
    version      INT NOT NULL PRIMARY KEY,
    applied_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS alembic_version (
    version_num  VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sectors (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(255) NOT NULL,
    edge_mpc            DOUBLE NOT NULL,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    ring_index          INT,
    layer_index         INT,
    ring_slot_index     INT,
    wiki_url            VARCHAR(2048),
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BIGINT UNSIGNED,
    version_key           CHAR(22),
    planetgen_version     VARCHAR(32),
    python_version        VARCHAR(32),
    platform              VARCHAR(64),
    UNIQUE KEY uq_sectors_uid (uid),
    CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    UNIQUE KEY uq_sectors_address (ring_index, layer_index, ring_slot_index),
    KEY idx_sectors_galactic_radius_pc (galactic_radius_pc),
    KEY idx_sectors_name (name),
    FULLTEXT KEY ft_sectors_name (name),
    KEY idx_sectors_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_sectors_modified_at (modified_at),
    KEY idx_sectors_version_key (version_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_shape (
    id                          BIGINT UNSIGNED PRIMARY KEY CHECK (id = 1),
    disk_scale_length_pc        DOUBLE NOT NULL,
    disk_scale_height_pc        DOUBLE NOT NULL,
    bulge_scale_radius_pc       DOUBLE NOT NULL,
    bulge_amplitude             DOUBLE NOT NULL,
    arm_count                   INT NOT NULL,
    pitch_angle_rad             DOUBLE NOT NULL,
    arm_amplitude               DOUBLE NOT NULL,
    spiral_reference_radius_pc  DOUBLE NOT NULL,
    spiral_reference_angle_rad  DOUBLE NOT NULL,
    k_norm                      DOUBLE NOT NULL,
    edge_pc                     DOUBLE NOT NULL,
    expected_system_count_at_density_1  DOUBLE NOT NULL,
    outer_ring_index            INT NOT NULL,
    bright_star_min_luminosity_sol  DOUBLE,
    bright_star_seed                BIGINT UNSIGNED,
    bright_star_mass_limit_sol      DOUBLE,
    phenomenon_scatter_seed         BIGINT UNSIGNED,
    phenomenon_min_mass_solar       DOUBLE,
    galaxy_seed                     BINARY(16),
    version_key                     CHAR(22),
    planetgen_version               VARCHAR(32),
    python_version                  VARCHAR(16),
    platform                        VARCHAR(64),
    density_ratio_avg               DOUBLE,
    density_ratio_samples           BIGINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_layer (
    layer_index       INT NOT NULL PRIMARY KEY,
    outer_ring_index  INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_column (
    ring_index       INT NOT NULL PRIMARY KEY,
    layer_index_min  INT NOT NULL,
    layer_index_max  INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orbit_simulation_state (
    id               BIGINT UNSIGNED PRIMARY KEY CHECK (id = 1),
    last_updated_at  TIMESTAMP NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_configs (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    markdown          TINYINT(1) NOT NULL DEFAULT 0 CHECK (markdown IN (0, 1)),
    habitable_world   TINYINT(1) CHECK (habitable_world IN (0, 1)),
    asteroid_belt     TINYINT(1) CHECK (asteroid_belt IN (0, 1)),
    comets            TINYINT(1) CHECK (comets IN (0, 1)),          -- v50
    large_star        TINYINT(1) CHECK (large_star IN (0, 1)),
    moons             TINYINT(1) CHECK (moons IN (0, 1)),
    max_planets       TINYINT(1) CHECK (max_planets IN (0, 1)),
    planets           TINYINT(1) CHECK (planets IN (0, 1)),
    star_type         VARCHAR(64),
    name              VARCHAR(255),
    age               VARCHAR(16) CHECK (age IN ('young', 'old')),
    intelligent_life  TINYINT(1) CHECK (intelligent_life IN (0, 1)),
    binary_system     TINYINT(1) CHECK (binary_system IN (0, 1)),
    wide_binary       TINYINT(1) CHECK (wide_binary IN (0, 1)),     -- v50
    num_orbits        INT,
    prevalence_habitable_world DOUBLE NOT NULL DEFAULT 0,  -- v54
    prevalence_asteroid_belt DOUBLE NOT NULL DEFAULT 0,
    prevalence_comets DOUBLE NOT NULL DEFAULT 0,
    prevalence_large_star DOUBLE NOT NULL DEFAULT 0,
    prevalence_moons DOUBLE NOT NULL DEFAULT 0,
    prevalence_max_planets DOUBLE NOT NULL DEFAULT 0,
    prevalence_intelligent_life DOUBLE NOT NULL DEFAULT 0,
    prevalence_binary_system DOUBLE NOT NULL DEFAULT 0,
    prevalence_wide_binary DOUBLE NOT NULL DEFAULT 0,
    prevalence_planets DOUBLE NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_config_slots (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    config_id     BIGINT UNSIGNED NOT NULL,
    orbit_index   INT NOT NULL,
    type          VARCHAR(16) CHECK (type IN ('planet', 'asteroid_belt')),
    planet_class  VARCHAR(16),
    moons         INT,
    CONSTRAINT fk_system_config_slots_config
        FOREIGN KEY (config_id) REFERENCES system_configs(id) ON DELETE CASCADE,
    KEY idx_system_config_slots_config_id (config_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS star_systems (
    id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id              BIGINT UNSIGNED,
    system_config_id       BIGINT UNSIGNED NOT NULL,
    name                   VARCHAR(255) NOT NULL,
    position_x_mpc          DOUBLE,
    position_y_mpc          DOUBLE,
    position_z_mpc          DOUBLE,
    quadrant                VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    location                TEXT,
    is_binary              TINYINT(1) NOT NULL DEFAULT 0 CHECK (is_binary IN (0, 1)),
    binary_configuration   VARCHAR(8) CHECK (binary_configuration IN ('close', 'wide')),
    binary_separation_km            DOUBLE,
    binary_eccentricity              DOUBLE,
    binary_periapsis_km              DOUBLE,
    binary_apoapsis_km               DOUBLE,
    binary_type                     VARCHAR(64),
    binary_temperature_k            DOUBLE,
    binary_radius_km                DOUBLE,
    binary_effective_mass_kg        DOUBLE,
    binary_effective_luminosity_w   DOUBLE,
    binary_age_gy                   DOUBLE,
    binary_lifespan_gy              DOUBLE,  -- NULL = float('inf')
    binary_habitable_zone_inner_km  DOUBLE,
    binary_habitable_zone_outer_km  DOUBLE,
    binary_system_perimeter_km      DOUBLE,
    binary_heliosphere_radius_km    DOUBLE,
    binary_galactic_orbital_speed_kms   DOUBLE,
    binary_galactic_orbital_period_gy   DOUBLE,
    binary_galactic_orbital_phase_deg          DOUBLE,  -- v13, see header comment
    binary_galactic_min_update_interval_years  DOUBLE,  -- v13, see header comment
    binary_mutual_orbital_period_years         DOUBLE,
    binary_mutual_orbital_speed_kms            DOUBLE,
    binary_mutual_orbital_inclination_deg      DOUBLE,
    binary_mutual_orbital_ascending_node_deg   DOUBLE,
    binary_mutual_orbital_phase_deg            DOUBLE,
    binary_epoch_unix                          DOUBLE,  -- v66 (GEN.106)
    binary_next_update_due                     DOUBLE,
    binary_mutual_min_update_interval_years    DOUBLE,
    binary_mutual_position_x_km   DOUBLE,
    binary_mutual_position_y_km   DOUBLE,
    binary_mutual_position_z_km   DOUBLE,
    binary_primary_position_x_km    DOUBLE,
    binary_primary_position_y_km    DOUBLE,
    binary_primary_position_z_km    DOUBLE,
    binary_secondary_position_x_km  DOUBLE,
    binary_secondary_position_y_km  DOUBLE,
    binary_secondary_position_z_km  DOUBLE,
    binary_secondary_mass_fraction  DOUBLE,
    binary_planetary_wobble_x_km    DOUBLE,
    binary_planetary_wobble_y_km    DOUBLE,
    binary_planetary_wobble_z_km    DOUBLE,
    system_flavor_text   TEXT,
    runaway_class        VARCHAR(16),
    runaway_speed_kms    DOUBLE,
    velocity_x_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms       DOUBLE NOT NULL DEFAULT 0,
    epoch_unix           DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due      DOUBLE,
    schema_version       INT NOT NULL DEFAULT 1,
    mediawiki_url        VARCHAR(2048),
    wikijs_url           VARCHAR(2048),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_star_systems_uid (uid),
    CONSTRAINT fk_star_systems_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    CONSTRAINT fk_star_systems_config
        FOREIGN KEY (system_config_id) REFERENCES system_configs(id),
    KEY idx_star_systems_sector_id (sector_id),
    KEY idx_star_systems_next_update_due (next_update_due),
    KEY idx_star_systems_binary_next_update_due (binary_next_update_due),
    KEY idx_star_systems_system_config_id (system_config_id),
    KEY idx_star_systems_name (name),
    FULLTEXT KEY ft_star_systems_name (name),
    KEY idx_star_systems_modified_at (modified_at),
    KEY idx_star_systems_quadrant (quadrant),
    CONSTRAINT fk_star_systems_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_star_systems_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS stars (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id            BIGINT UNSIGNED NOT NULL,
    role                      VARCHAR(16) NOT NULL CHECK (role IN ('primary', 'secondary', 'single')),
    name                      VARCHAR(255) NOT NULL,
    star_type                 VARCHAR(64) NOT NULL,   -- Star.type, e.g. "G2V Yellow Main Sequence Star"
    yerkes_class              VARCHAR(16) NOT NULL,
    mass_kg                   DOUBLE NOT NULL,
    radius_km                 DOUBLE NOT NULL,
    temperature_k             DOUBLE NOT NULL,
    luminosity_w              DOUBLE NOT NULL,
    age_gy                    DOUBLE NOT NULL,
    lifespan_gy               DOUBLE,            -- NULL = float('inf'), white dwarfs
    habitable_zone_inner_km   DOUBLE NOT NULL,
    habitable_zone_outer_km   DOUBLE NOT NULL,
    system_perimeter_km       DOUBLE NOT NULL,
    heliosphere_radius_km     DOUBLE NOT NULL,
    galactic_orbital_speed_kms    DOUBLE NOT NULL,
    galactic_orbital_period_gy    DOUBLE NOT NULL,
    galactic_orbital_phase_deg          DOUBLE NOT NULL,  -- v13, see header comment
    galactic_min_update_interval_years  DOUBLE NOT NULL,  -- v13, see header comment
    wide_binary_a_crit_km               DOUBLE,
    reflex_offset_x_km       DOUBLE,
    reflex_offset_y_km       DOUBLE,
    reflex_offset_z_km       DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    log_lx_lbol                 DOUBLE,
    l_xuv_w                     DOUBLE,
    xuv_saturated               BOOLEAN,
    flare_n33_per_yr            DOUBLE,
    flare_alpha                 DOUBLE,
    xuv_fluence_j               DOUBLE,
    lethal_event_rate_per_gyr   DOUBLE,
    uid                   BIGINT UNSIGNED,
    UNIQUE KEY uq_stars_uid (star_system_id, uid),
    CONSTRAINT fk_stars_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    KEY idx_stars_star_system_id (star_system_id),
    KEY idx_stars_name (name),
    FULLTEXT KEY ft_stars_name (name),
    KEY idx_stars_yerkes_class (yerkes_class),
    KEY idx_stars_radius_km (radius_km),
    KEY idx_stars_star_type (star_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planets (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id            BIGINT UNSIGNED NOT NULL,
    star_id                   BIGINT UNSIGNED,
    orbital_index             INT NOT NULL,
    body_type                 VARCHAR(4) NOT NULL CHECK (body_type IN ('t', 'g')),
    name                      VARCHAR(255) NOT NULL,
    planet_class              VARCHAR(16),
    distance_km               DOUBLE NOT NULL,   -- from the star
    radius_km                 DOUBLE NOT NULL,
    mass_kg                   DOUBLE NOT NULL,
    volume_km3                DOUBLE NOT NULL,   -- derived, stored not recomputed
    period_years              DOUBLE NOT NULL,   -- derived, stored not recomputed
    zone                      VARCHAR(4) CHECK (zone IN ('h', 'e', 'c')),
    description               TEXT,
    gravity_g                 DOUBLE,
    surface_temperature_k     DOUBLE,
    density_g_cm3             DOUBLE,
    atmosphere                TEXT,
    atm_density               DOUBLE,
    atm_molar_density         DOUBLE,
    atmospheric_pressure_pa   DOUBLE,
    composition               TEXT,            -- descriptive string (contrast asteroid_belt_composition)
    scale_height_km           DOUBLE,
    hill_radius_km            DOUBLE,
    min_orbit_distance_km     DOUBLE,
    habitable_zone_inner_km   DOUBLE NOT NULL,   -- copied from host star at generation time
    habitable_zone_outer_km   DOUBLE NOT NULL,
    life_chemical             VARCHAR(64),
    evolutionary_speed        VARCHAR(64),
    flavor_text               TEXT,
    flavor_text_count         INT NOT NULL DEFAULT 0,
    orbital_inclination_deg     DOUBLE NOT NULL,
    orbital_ascending_node_deg  DOUBLE NOT NULL,
    orbital_phase_deg           DOUBLE NOT NULL,
    position_x_km               DOUBLE NOT NULL,
    position_y_km               DOUBLE NOT NULL,
    position_z_km               DOUBLE NOT NULL,
    orbital_speed_kms           DOUBLE NOT NULL,
    velocity_x_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms              DOUBLE NOT NULL DEFAULT 0,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    min_update_interval_years   DOUBLE NOT NULL,  -- v12, see header comment
    rotation_period_hours       DOUBLE NOT NULL,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    mantle_redox                VARCHAR(16) CHECK (mantle_redox IN ('reduced', 'intermediate', 'oxidized')),
    mantle_delta_iw             DOUBLE,
    p_o2_kpa                      DOUBLE,
    p_co2_kpa                     DOUBLE,
    p_co_kpa                      DOUBLE,
    p_n2_kpa                      DOUBLE,
    p_ar_kpa                      DOUBLE,
    p_h2_kpa                      DOUBLE,
    p_h2o_kpa                     DOUBLE,
    p_ch4_kpa                     DOUBLE,
    p_h2s_kpa                     DOUBLE,
    p_so2_kpa                     DOUBLE,
    magnetic_moment_a_m2        DOUBLE,
    dipole_class                VARCHAR(16) CHECK (dipole_class IN ('none', 'weak', 'earth-like', 'strong', 'multipolar')),
    magnetopause_rp             DOUBLE,
    xuv_flux_earth              DOUBLE,
    xuv_exposure_index          DOUBLE,
    flare_irradiation_index     DOUBLE,
    water_mass_fraction         DOUBLE,
    hydrosphere                 VARCHAR(20) CHECK (hydrosphere IN ('dry', 'vapour', 'ice', 'ice-covered ocean', 'surface ocean', 'hycean')),
    ocean_fraction              DOUBLE,
    land_fraction               DOUBLE,
    ocean_depth_km              DOUBLE,
    ice_shell_km                DOUBLE,
    hp_ice_km                   DOUBLE,
    ocean_class                 VARCHAR(16) CHECK (ocean_class IN ('ice-sealed', 'chloride brine', 'acid sulfate', 'soda', 'neutral')),
    ocean_ph                    DOUBLE,
    water_activity              DOUBLE,
    phosphorus                  VARCHAR(8) CHECK (phosphorus IN ('high', 'limited', 'starved')),
    surface_dose_msv_yr         DOUBLE,
    dose_gcr_msv_yr             DOUBLE,
    dose_sep_msv_yr             DOUBLE,
    dose_ground_msv_yr          DOUBLE,
    dose_helio_mult             DOUBLE,
    uv_surface_index            DOUBLE,
    ozone_loss_flag             BOOLEAN,
    phi4                        DOUBLE,
    phi4_pressure               DOUBLE,
    phi4_temperature            DOUBLE,
    phi4_chemistry              DOUBLE,
    phi4_radiation              DOUBLE,
    tier_pressure               TINYINT,
    tier_temperature            TINYINT,
    tier_chemistry              TINYINT,
    tier_radiation              TINYINT,
    phi_bio                     DOUBLE,
    phi_cpx                     DOUBLE,
    phi_tech                    DOUBLE,
    l_solv                      DOUBLE,
    l_chem                      DOUBLE,
    l_ener                      DOUBLE,
    l_rad                       DOUBLE,
    equipment_tier              TINYINT,
    hab_note                    VARCHAR(255),
    energy_flux_w_m2            DOUBLE,
    reflex_offset_x_km       DOUBLE,
    reflex_offset_y_km       DOUBLE,
    reflex_offset_z_km       DOUBLE,
    uid                   BIGINT UNSIGNED,
    UNIQUE KEY uq_planets_uid (star_system_id, uid),
    CONSTRAINT fk_planets_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_planets_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_planets_star_system_id (star_system_id),
    KEY idx_planets_next_update_due (next_update_due),
    KEY idx_planets_star_id (star_id),
    KEY idx_planets_name (name),
    FULLTEXT KEY ft_planets_name (name),
    KEY idx_planets_planet_class (planet_class),
    KEY idx_planets_body_type (body_type),
    KEY idx_planets_life_chemical (life_chemical),
    KEY idx_planets_radius_km (radius_km)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planet_evolutionary_paragraphs (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id   BIGINT UNSIGNED NOT NULL,
    position    INT NOT NULL,
    paragraph   TEXT NOT NULL,
    CONSTRAINT fk_planet_evolutionary_paragraphs_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    KEY idx_planet_evolutionary_paragraphs_planet_id (planet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planet_reflection_spectrum (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id      BIGINT UNSIGNED NOT NULL,
    spectrum_type  VARCHAR(16) NOT NULL CHECK (spectrum_type IN ('visible', 'non_visible')),
    position       INT NOT NULL,
    value          VARCHAR(255) NOT NULL,
    CONSTRAINT fk_planet_reflection_spectrum_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    KEY idx_planet_reflection_spectrum_planet_id (planet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moons (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id                 BIGINT UNSIGNED NOT NULL,
    star_system_id            BIGINT UNSIGNED NOT NULL,
    star_id                   BIGINT UNSIGNED,
    orbital_index             INT NOT NULL,   -- position in the parent planet's moons list
    body_type                 VARCHAR(4) NOT NULL CHECK (body_type IN ('t', 'g')),
    name                      VARCHAR(255) NOT NULL,
    planet_class              VARCHAR(16),
    distance_km               DOUBLE NOT NULL,   -- from the parent planet
    radius_km                 DOUBLE NOT NULL,
    mass_kg                   DOUBLE NOT NULL,
    volume_km3                DOUBLE NOT NULL,
    period_years              DOUBLE NOT NULL,
    zone                      VARCHAR(4) CHECK (zone IN ('h', 'e', 'c')),
    description               TEXT,
    gravity_g                 DOUBLE,
    surface_temperature_k     DOUBLE,
    density_g_cm3             DOUBLE,
    atmosphere                TEXT,
    atm_density               DOUBLE,
    atm_molar_density         DOUBLE,
    atmospheric_pressure_pa   DOUBLE,
    composition               TEXT,
    scale_height_km           DOUBLE,
    hill_radius_km            DOUBLE,
    min_orbit_distance_km     DOUBLE,
    habitable_zone_inner_km   DOUBLE NOT NULL,
    habitable_zone_outer_km   DOUBLE NOT NULL,
    life_chemical             VARCHAR(64),
    evolutionary_speed        VARCHAR(64),
    flavor_text               TEXT,
    flavor_text_count         INT NOT NULL DEFAULT 0,
    orbital_inclination_deg     DOUBLE NOT NULL,
    orbital_ascending_node_deg  DOUBLE NOT NULL,
    orbital_phase_deg           DOUBLE NOT NULL,
    position_x_km               DOUBLE NOT NULL,
    position_y_km               DOUBLE NOT NULL,
    position_z_km               DOUBLE NOT NULL,
    orbital_speed_kms           DOUBLE NOT NULL,
    velocity_x_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms              DOUBLE NOT NULL DEFAULT 0,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    min_update_interval_years   DOUBLE NOT NULL,  -- v12, see header comment
    rotation_period_hours       DOUBLE NOT NULL,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    mantle_redox                VARCHAR(16) CHECK (mantle_redox IN ('reduced', 'intermediate', 'oxidized')),
    mantle_delta_iw             DOUBLE,
    p_o2_kpa                      DOUBLE,
    p_co2_kpa                     DOUBLE,
    p_co_kpa                      DOUBLE,
    p_n2_kpa                      DOUBLE,
    p_ar_kpa                      DOUBLE,
    p_h2_kpa                      DOUBLE,
    p_h2o_kpa                     DOUBLE,
    p_ch4_kpa                     DOUBLE,
    p_h2s_kpa                     DOUBLE,
    p_so2_kpa                     DOUBLE,
    magnetic_moment_a_m2        DOUBLE,
    dipole_class                VARCHAR(16) CHECK (dipole_class IN ('none', 'weak', 'earth-like', 'strong', 'multipolar')),
    magnetopause_rp             DOUBLE,
    xuv_flux_earth              DOUBLE,
    xuv_exposure_index          DOUBLE,
    flare_irradiation_index     DOUBLE,
    water_mass_fraction         DOUBLE,
    hydrosphere                 VARCHAR(20) CHECK (hydrosphere IN ('dry', 'vapour', 'ice', 'ice-covered ocean', 'surface ocean', 'hycean')),
    ocean_fraction              DOUBLE,
    land_fraction               DOUBLE,
    ocean_depth_km              DOUBLE,
    ice_shell_km                DOUBLE,
    hp_ice_km                   DOUBLE,
    ocean_class                 VARCHAR(16) CHECK (ocean_class IN ('ice-sealed', 'chloride brine', 'acid sulfate', 'soda', 'neutral')),
    ocean_ph                    DOUBLE,
    water_activity              DOUBLE,
    phosphorus                  VARCHAR(8) CHECK (phosphorus IN ('high', 'limited', 'starved')),
    surface_dose_msv_yr         DOUBLE,
    dose_gcr_msv_yr             DOUBLE,
    dose_sep_msv_yr             DOUBLE,
    dose_ground_msv_yr          DOUBLE,
    dose_helio_mult             DOUBLE,
    uv_surface_index            DOUBLE,
    ozone_loss_flag             BOOLEAN,
    phi4                        DOUBLE,
    phi4_pressure               DOUBLE,
    phi4_temperature            DOUBLE,
    phi4_chemistry              DOUBLE,
    phi4_radiation              DOUBLE,
    tier_pressure               TINYINT,
    tier_temperature            TINYINT,
    tier_chemistry              TINYINT,
    tier_radiation              TINYINT,
    phi_bio                     DOUBLE,
    phi_cpx                     DOUBLE,
    phi_tech                    DOUBLE,
    l_solv                      DOUBLE,
    l_chem                      DOUBLE,
    l_ener                      DOUBLE,
    l_rad                       DOUBLE,
    equipment_tier              TINYINT,
    hab_note                    VARCHAR(255),
    energy_flux_w_m2            DOUBLE,
    uid                   BIGINT UNSIGNED,
    UNIQUE KEY uq_moons_uid (star_system_id, uid),
    CONSTRAINT fk_moons_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    CONSTRAINT fk_moons_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_moons_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_moons_planet_id (planet_id),
    KEY idx_moons_next_update_due (next_update_due),
    KEY idx_moons_star_system_id (star_system_id),
    KEY idx_moons_star_id (star_id),
    KEY idx_moons_name (name),
    FULLTEXT KEY ft_moons_name (name),
    KEY idx_moons_planet_class (planet_class),
    KEY idx_moons_body_type (body_type),
    KEY idx_moons_life_chemical (life_chemical),
    KEY idx_moons_radius_km (radius_km)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moon_evolutionary_paragraphs (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    moon_id     BIGINT UNSIGNED NOT NULL,
    position    INT NOT NULL,
    paragraph   TEXT NOT NULL,
    CONSTRAINT fk_moon_evolutionary_paragraphs_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    KEY idx_moon_evolutionary_paragraphs_moon_id (moon_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moon_reflection_spectrum (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    moon_id        BIGINT UNSIGNED NOT NULL,
    spectrum_type  VARCHAR(16) NOT NULL CHECK (spectrum_type IN ('visible', 'non_visible')),
    position       INT NOT NULL,
    value          VARCHAR(255) NOT NULL,
    CONSTRAINT fk_moon_reflection_spectrum_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    KEY idx_moon_reflection_spectrum_moon_id (moon_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_belts (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id       BIGINT UNSIGNED NOT NULL,
    star_id              BIGINT UNSIGNED,
    orbital_index        INT NOT NULL,
    distance_km          DOUBLE NOT NULL,
    lower_limit_km       DOUBLE NOT NULL,   -- distance, low (asteroidData.py's "distance_text" range)
    upper_limit_km       DOUBLE NOT NULL,   -- distance, high
    density              VARCHAR(16) NOT NULL CHECK (density IN ('dense', 'sparse', 'typical')),
    composition_summary  TEXT NOT NULL,
    uid                   BIGINT UNSIGNED,
    UNIQUE KEY uq_asteroid_belts_uid (star_system_id, uid),
    CONSTRAINT fk_asteroid_belts_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_asteroid_belts_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_asteroid_belts_star_system_id (star_system_id),
    KEY idx_asteroid_belts_star_id (star_id),
    KEY idx_asteroid_belts_density (density)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_belt_composition (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    belt_id        BIGINT UNSIGNED NOT NULL,
    position       INT NOT NULL,
    component      VARCHAR(64) NOT NULL,
    concentration  VARCHAR(16) NOT NULL CHECK (concentration IN ('high', 'moderate', 'small', 'trace')),
    CONSTRAINT fk_asteroid_belt_composition_belt
        FOREIGN KEY (belt_id) REFERENCES asteroid_belts(id) ON DELETE CASCADE,
    KEY idx_asteroid_belt_composition_belt_id (belt_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS comets (
    id                          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id              BIGINT UNSIGNED NOT NULL,
    star_id                     BIGINT UNSIGNED,
    name                        VARCHAR(255) NOT NULL,
    orbit_type                  VARCHAR(16) NOT NULL CHECK (orbit_type IN ('elliptical', 'parabolic')),
    period_class                VARCHAR(16) CHECK (period_class IN ('jupiter_family', 'halley_type', 'long_period')),
    nucleus_diameter_km         DOUBLE NOT NULL,
    composition_summary         TEXT NOT NULL,
    perihelion_distance_km      DOUBLE NOT NULL,
    eccentricity                DOUBLE NOT NULL,
    inclination_deg             DOUBLE NOT NULL,
    arg_periapsis_deg           DOUBLE NOT NULL,
    ascending_node_deg          DOUBLE NOT NULL,
    orbital_period_years        DOUBLE,
    mean_anomaly_deg            DOUBLE,
    parabolic_mean_anomaly      DOUBLE,
    min_update_interval_years   DOUBLE,
    primary_mass_solar          DOUBLE NOT NULL,
    is_active                   TINYINT(1) NOT NULL CHECK (is_active IN (0, 1)),
    distance_km                 DOUBLE NOT NULL,
    position_x_km               DOUBLE NOT NULL,
    position_y_km               DOUBLE NOT NULL,
    position_z_km               DOUBLE NOT NULL,
    orbital_speed_kms           DOUBLE NOT NULL,
    velocity_x_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms              DOUBLE NOT NULL DEFAULT 0,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    uid                   BIGINT UNSIGNED,
    UNIQUE KEY uq_comets_uid (star_system_id, uid),
    CONSTRAINT fk_comets_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_comets_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_comets_star_system_id (star_system_id),
    KEY idx_comets_next_update_due (next_update_due),
    KEY idx_comets_star_id (star_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS comet_composition (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    comet_id    BIGINT UNSIGNED NOT NULL,
    position    INT NOT NULL,
    component   VARCHAR(64) NOT NULL,
    CONSTRAINT fk_comet_composition_comet
        FOREIGN KEY (comet_id) REFERENCES comets(id) ON DELETE CASCADE,
    KEY idx_comet_composition_comet_id (comet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS black_holes (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_id                   BIGINT UNSIGNED,
    sector_id                 BIGINT UNSIGNED,
    name                      VARCHAR(255) NOT NULL,
    mass_class                VARCHAR(16) NOT NULL DEFAULT 'stellar',
    mass_solar                DOUBLE NOT NULL,
    event_horizon_radius_km   DOUBLE NOT NULL,
    spin                      DOUBLE NOT NULL,
    has_accretion_disk        TINYINT(1) NOT NULL CHECK (has_accretion_disk IN (0, 1)),
    temperature_k             DOUBLE NOT NULL,
    luminosity_w              DOUBLE NOT NULL,
    age_gy                    DOUBLE NOT NULL,
    galactic_orbital_speed_kms           DOUBLE,
    galactic_orbital_period_gy           DOUBLE,
    galactic_orbital_phase_deg           DOUBLE,
    galactic_min_update_interval_years   DOUBLE,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_black_holes_uid (uid),
    KEY idx_black_holes_name (name),  -- v40: name uniqueness lookups
    KEY idx_black_holes_next_update_due (next_update_due),
    CONSTRAINT chk_black_holes_mass_class CHECK (mass_class IN ('stellar', 'intermediate', 'supermassive')),
    CONSTRAINT chk_black_holes_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_black_holes_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE CASCADE,
    CONSTRAINT fk_black_holes_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_black_holes_star_id (star_id),
    KEY idx_black_holes_sector_id (sector_id),
    KEY idx_black_holes_galactic_radius_pc (galactic_radius_pc),
    KEY idx_black_holes_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_black_holes_modified_at (modified_at),
    CONSTRAINT fk_black_holes_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_black_holes_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS neutron_stars (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_id                   BIGINT UNSIGNED,
    sector_id                 BIGINT UNSIGNED,
    name                      VARCHAR(255) NOT NULL,
    mass_solar                DOUBLE NOT NULL,
    radius_km                 DOUBLE NOT NULL,
    spin_period_ms            DOUBLE NOT NULL,
    magnetic_field_gauss      DOUBLE NOT NULL,
    pulsar_type               VARCHAR(16) NOT NULL CHECK (pulsar_type IN ('young', 'millisecond', 'non-pulsing')),
    surface_temperature_k     DOUBLE NOT NULL,
    luminosity_w              DOUBLE NOT NULL,
    age_gy                    DOUBLE NOT NULL,
    galactic_orbital_speed_kms           DOUBLE,
    galactic_orbital_period_gy           DOUBLE,
    galactic_orbital_phase_deg           DOUBLE,
    galactic_min_update_interval_years   DOUBLE,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_neutron_stars_uid (uid),
    KEY idx_neutron_stars_name (name),  -- v40: name uniqueness lookups
    KEY idx_neutron_stars_next_update_due (next_update_due),
    CONSTRAINT chk_neutron_stars_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_neutron_stars_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE CASCADE,
    CONSTRAINT fk_neutron_stars_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_neutron_stars_star_id (star_id),
    KEY idx_neutron_stars_sector_id (sector_id),
    KEY idx_neutron_stars_galactic_radius_pc (galactic_radius_pc),
    KEY idx_neutron_stars_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_neutron_stars_modified_at (modified_at),
    CONSTRAINT fk_neutron_stars_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_neutron_stars_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebulae (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id         BIGINT UNSIGNED,
    name              VARCHAR(255) NOT NULL,
    nebula_class      CHAR(1) NOT NULL,
    nebula_type       VARCHAR(16) NOT NULL,
    radius_ly         DOUBLE NOT NULL,
    composition       TEXT NOT NULL,
    formation_cause   TEXT NOT NULL,
    dominant_species  VARCHAR(255) NOT NULL,
    density_cm3       DOUBLE NOT NULL,
    temperature_k     DOUBLE NOT NULL,
    extinction_av     DOUBLE NOT NULL,
    galactic_orbital_speed_kms           DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    shape_axis_x          DOUBLE,
    shape_axis_y          DOUBLE,
    shape_axis_z          DOUBLE,
    shape_angle_x         DOUBLE,
    shape_angle_y         DOUBLE,
    shape_angle_z         DOUBLE,
    shape_warp_amplitude  DOUBLE,
    shape_warp_frequency  DOUBLE,
    shape_warp_octaves    INT,
    shape_noise_seed      BIGINT UNSIGNED,
    shape_iso             DOUBLE,
    shape_scale           DOUBLE,
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_nebulae_uid (uid),
    KEY idx_nebulae_name (name),  -- v40: name uniqueness lookups
    KEY idx_nebulae_next_update_due (next_update_due),
    CONSTRAINT chk_nebulae_type CHECK (nebula_type IN ('diffuse', 'emission', 'reflection', 'planetary', 'dark')),
    CONSTRAINT chk_nebulae_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_nebulae_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_nebulae_sector_id (sector_id),
    KEY idx_nebulae_galactic_radius_pc (galactic_radius_pc),
    KEY idx_nebulae_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_nebulae_modified_at (modified_at),
    CONSTRAINT fk_nebulae_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_nebulae_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebula_shape_balls (
    nebula_id   BIGINT UNSIGNED NOT NULL,
    ball_index  INT NOT NULL,
    center_x    DOUBLE NOT NULL,
    center_y    DOUBLE NOT NULL,
    center_z    DOUBLE NOT NULL,
    radius      DOUBLE NOT NULL,
    PRIMARY KEY (nebula_id, ball_index),
    CONSTRAINT fk_nebula_shape_balls_nebula
        FOREIGN KEY (nebula_id) REFERENCES nebulae(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS supernova_remnants (
    id                                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id                         BIGINT UNSIGNED,
    name                              VARCHAR(255) NOT NULL,
    remnant_class                     CHAR(1) NOT NULL,
    morphology                        VARCHAR(16) NOT NULL CHECK (morphology IN ('shell', 'plerion', 'composite')),
    age_years                         DOUBLE NOT NULL,
    radius_ly                         DOUBLE NOT NULL,
    progenitor_type                   VARCHAR(16) NOT NULL CHECK (progenitor_type IN ('Type Ia', 'core-collapse')),
    compact_remnant_kind              VARCHAR(16) CHECK (compact_remnant_kind IN ('black_hole', 'neutron_star')),
    compact_remnant_black_hole_id     BIGINT UNSIGNED,
    compact_remnant_neutron_star_id   BIGINT UNSIGNED,
    dominant_species                  VARCHAR(255) NOT NULL,
    density_cm3                       DOUBLE NOT NULL,
    temperature_k                     DOUBLE NOT NULL,
    extinction_av                     DOUBLE NOT NULL,
    galactic_orbital_speed_kms           DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_supernova_remnants_uid (uid),
    KEY idx_supernova_remnants_name (name),  -- v40: name uniqueness lookups
    KEY idx_supernova_remnants_next_update_due (next_update_due),
    CONSTRAINT chk_supernova_remnants_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_supernova_remnants_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    CONSTRAINT fk_supernova_remnants_black_hole
        FOREIGN KEY (compact_remnant_black_hole_id) REFERENCES black_holes(id) ON DELETE SET NULL,
    CONSTRAINT fk_supernova_remnants_neutron_star
        FOREIGN KEY (compact_remnant_neutron_star_id) REFERENCES neutron_stars(id) ON DELETE SET NULL,
    KEY idx_supernova_remnants_sector_id (sector_id),
    KEY idx_supernova_remnants_galactic_radius_pc (galactic_radius_pc),
    KEY idx_supernova_remnants_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_supernova_remnants_modified_at (modified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS quasars (
    id                              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id                       BIGINT UNSIGNED,
    name                            VARCHAR(255) NOT NULL,
    black_hole_mass_solar           DOUBLE NOT NULL,
    event_horizon_radius_km         DOUBLE NOT NULL,
    eddington_ratio                 DOUBLE NOT NULL,
    luminosity_w                    DOUBLE NOT NULL,
    accretion_rate_solar_per_year   DOUBLE NOT NULL,
    broad_line_region_light_days    DOUBLE NOT NULL,
    is_radio_loud                   TINYINT(1) NOT NULL CHECK (is_radio_loud IN (0, 1)),
    jet_length_ly                   DOUBLE,
    active_age_years                DOUBLE NOT NULL,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_quasars_uid (uid),
    KEY idx_quasars_name (name),  -- v40: name uniqueness lookups
    CONSTRAINT chk_quasars_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_quasars_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    KEY idx_quasars_sector_id (sector_id),
    KEY idx_quasars_galactic_radius_pc (galactic_radius_pc),
    KEY idx_quasars_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_quasars_modified_at (modified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS rogue_planets (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id           BIGINT UNSIGNED,
    name                VARCHAR(255) NOT NULL,
    planet_type         VARCHAR(4) NOT NULL CHECK (planet_type IN ('t', 'g')),
    planet_class        VARCHAR(4),
    mass_bin            VARCHAR(16) NOT NULL DEFAULT 'terrestrial',
    mass_kg             DOUBLE NOT NULL,
    radius_km           DOUBLE NOT NULL,
    composition         TEXT NOT NULL,
    has_internal_heat   TINYINT(1) NOT NULL CHECK (has_internal_heat IN (0, 1)),
    has_moons           TINYINT(1) NOT NULL CHECK (has_moons IN (0, 1)),
    age_gy                   DOUBLE,
    internal_heat_flux_w_m2  DOUBLE,
    effective_temperature_k  DOUBLE,
    surface_regime           VARCHAR(24),
    surface_temperature_k    DOUBLE,
    surface_pressure_pa      DOUBLE,
    ice_shell_thickness_km   DOUBLE,
    ocean_depth_km           DOUBLE,
    has_liquid_water         TINYINT(1),
    hp_ice_km                DOUBLE,  -- v74 (GEN.88)
    galactic_orbital_speed_kms           DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_rogue_planets_uid (uid),
    KEY idx_rogue_planets_name (name),  -- v40: name uniqueness lookups
    KEY idx_rogue_planets_next_update_due (next_update_due),
    CONSTRAINT chk_rogue_planets_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_rogue_planets_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    KEY idx_rogue_planets_sector_id (sector_id),
    KEY idx_rogue_planets_galactic_radius_pc (galactic_radius_pc),
    KEY idx_rogue_planets_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_rogue_planets_modified_at (modified_at),
    CONSTRAINT fk_rogue_planets_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_rogue_planets_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS interstellar_comets (
    id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id              BIGINT UNSIGNED,
    name                   VARCHAR(255) NOT NULL,
    nucleus_diameter_km    DOUBLE NOT NULL,
    velocity_kms           DOUBLE NOT NULL,
    is_active              TINYINT(1) NOT NULL CHECK (is_active IN (0, 1)),
    composition_summary    TEXT NOT NULL,
    galactic_orbital_speed_kms           DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_interstellar_comets_uid (uid),
    CONSTRAINT chk_interstellar_comets_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_interstellar_comets_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    KEY idx_interstellar_comets_sector_id (sector_id),
    KEY idx_interstellar_comets_next_update_due (next_update_due),
    KEY idx_interstellar_comets_galactic_radius_pc (galactic_radius_pc),
    KEY idx_interstellar_comets_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_interstellar_comets_modified_at (modified_at),
    CONSTRAINT fk_interstellar_comets_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_interstellar_comets_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS interstellar_comet_composition (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    comet_id    BIGINT UNSIGNED NOT NULL,
    position    INT NOT NULL,
    component   VARCHAR(64) NOT NULL,
    CONSTRAINT fk_interstellar_comet_composition_comet
        FOREIGN KEY (comet_id) REFERENCES interstellar_comets(id) ON DELETE CASCADE,
    KEY idx_interstellar_comet_composition_comet_id (comet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_fields (
    id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id             BIGINT UNSIGNED,
    name                  VARCHAR(255) NOT NULL,
    field_class           VARCHAR(4) NOT NULL,
    composition_family    VARCHAR(16) NOT NULL,
    density               VARCHAR(16) NOT NULL CHECK (density IN ('dense', 'sparse', 'typical')),
    radius_ly             DOUBLE NOT NULL,
    composition_summary   TEXT NOT NULL,
    galactic_orbital_speed_kms           DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_asteroid_fields_uid (uid),
    CONSTRAINT chk_asteroid_fields_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_asteroid_fields_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_asteroid_fields_sector_id (sector_id),
    KEY idx_asteroid_fields_next_update_due (next_update_due),
    KEY idx_asteroid_fields_galactic_radius_pc (galactic_radius_pc),
    KEY idx_asteroid_fields_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_asteroid_fields_modified_at (modified_at),
    CONSTRAINT fk_asteroid_fields_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_asteroid_fields_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_field_composition (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    field_id       BIGINT UNSIGNED NOT NULL,
    position       INT NOT NULL,
    component      VARCHAR(64) NOT NULL,
    concentration  VARCHAR(16) NOT NULL CHECK (concentration IN ('high', 'moderate', 'small', 'trace')),
    CONSTRAINT fk_asteroid_field_composition_field
        FOREIGN KEY (field_id) REFERENCES asteroid_fields(id) ON DELETE CASCADE,
    KEY idx_asteroid_field_composition_field_id (field_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_name_registry (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    base_name         VARCHAR(255) NOT NULL,
    occurrence_count  INT NOT NULL,
    first_sector_id   BIGINT UNSIGNED NOT NULL,
    UNIQUE (base_name),
    CONSTRAINT fk_sector_name_registry_first_sector
        FOREIGN KEY (first_sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_name_registry (
    id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    base_name              VARCHAR(255) NOT NULL,
    occurrence_count       INT NOT NULL,
    first_star_system_id   BIGINT UNSIGNED,
    first_object_table     VARCHAR(32),
    first_object_id        BIGINT UNSIGNED,
    diminutive_index       INT,
    UNIQUE (base_name),
    CONSTRAINT fk_system_name_registry_first_star_system
        FOREIGN KEY (first_star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nearest_systems (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id            BIGINT UNSIGNED NOT NULL,
    object_table         VARCHAR(32) NOT NULL,
    object_id            BIGINT UNSIGNED NOT NULL,
    star_system_id       BIGINT UNSIGNED,
    neighbor_rank        TINYINT NOT NULL,
    neighbor_system_id   BIGINT UNSIGNED NOT NULL,
    distance_pc          DOUBLE NOT NULL,
    UNIQUE KEY uq_nearest_systems_object_rank (object_table, object_id, neighbor_rank),
    KEY idx_nearest_systems_neighbor (neighbor_system_id),
    CONSTRAINT fk_nearest_systems_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    CONSTRAINT fk_nearest_systems_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_nearest_systems_neighbor
        FOREIGN KEY (neighbor_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS facilities (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(255) NOT NULL,
    kind                 VARCHAR(16) NOT NULL,
    placement            VARCHAR(16) NOT NULL,
    host_type            VARCHAR(16) NOT NULL,
    star_system_id       BIGINT UNSIGNED,
    star_id              BIGINT UNSIGNED,
    planet_id            BIGINT UNSIGNED,
    moon_id              BIGINT UNSIGNED,
    asteroid_belt_id     BIGINT UNSIGNED,
    asteroid_field_id    BIGINT UNSIGNED,
    sector_id            BIGINT UNSIGNED,
    center_x_pc          DOUBLE,
    center_y_pc          DOUBLE,
    center_z_pc          DOUBLE,
    galactic_radius_pc   DOUBLE,
    velocity_x_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms       DOUBLE NOT NULL DEFAULT 0,
    orbit_distance_km    DOUBLE,
    orbit_period_years   DOUBLE,
    orbital_speed_kms    DOUBLE,
    orbit_phase_deg      DOUBLE,
    epoch_unix           DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due      DOUBLE,
    description          TEXT,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    KEY idx_facilities_star_system (star_system_id),
    KEY idx_facilities_next_update_due (next_update_due),
    KEY idx_facilities_sector (sector_id),
    KEY idx_facilities_name (name),
    CONSTRAINT chk_facilities_kind CHECK (kind IN ('colony', 'outpost', 'mining-colony', 'station', 'starbase')),
    CONSTRAINT chk_facilities_placement CHECK (placement IN ('terrestrial', 'orbital', 'asteroid', 'standalone')),
    CONSTRAINT fk_facilities_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_asteroid_belt
        FOREIGN KEY (asteroid_belt_id) REFERENCES asteroid_belts(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_asteroid_field
        FOREIGN KEY (asteroid_field_id) REFERENCES asteroid_fields(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bright_stars (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ring_index           INT NOT NULL,
    layer_index          SMALLINT NOT NULL,
    ring_slot_index      INT NOT NULL,
    position_x_mpc       BIGINT NOT NULL,
    position_y_mpc       BIGINT NOT NULL,
    position_z_mpc       BIGINT NOT NULL,
    population           VARCHAR(12) NOT NULL,
    star_type            VARCHAR(64) NOT NULL,
    yerkes_class         VARCHAR(16) NOT NULL,
    mass_kg              DOUBLE NOT NULL,
    radius_km            DOUBLE NOT NULL,
    temperature_k        DOUBLE NOT NULL,
    luminosity_w         DOUBLE NOT NULL,
    age_gy               DOUBLE NOT NULL,
    lifespan_gy          DOUBLE,
    initial_mass_sol     DOUBLE NOT NULL,
    phase_end_age_gy     DOUBLE,
    seed                 BIGINT UNSIGNED NOT NULL,
    star_system_id       BIGINT UNSIGNED,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    off_plane            TINYINT AS (ABS(position_z_mpc) >= 250000) VIRTUAL,
    KEY idx_bright_stars_address (ring_index, layer_index, ring_slot_index),
    KEY idx_bright_stars_luminosity (luminosity_w),
    KEY idx_bright_stars_population (population, off_plane, luminosity_w),
    CONSTRAINT chk_bright_stars_population CHECK (population IN ('young', 'intermediate', 'old', 'bulge')),
    CONSTRAINT fk_bright_stars_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_stats (
    ring_index             INT NOT NULL,
    layer_index            SMALLINT NOT NULL,
    ring_slot_index        INT NOT NULL,
    bright_level_sol       DOUBLE NOT NULL DEFAULT -1,
    level_before_fill_sol  DOUBLE,
    relative_density       DOUBLE,
    expected_systems       DOUBLE,
    actual_systems         INT,
    actual_stars           INT,
    mean_temperature_k     DOUBLE,
    mean_luminosity_sol    DOUBLE,
    mean_age_gy            DOUBLE,
    total_luminosity_sol   DOUBLE,
    filled_at              TIMESTAMP(3) NULL,
    updated_at             TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (ring_index, layer_index, ring_slot_index),
    KEY idx_sector_stats_level (bright_level_sol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_paths (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id       BIGINT UNSIGNED NOT NULL,
    object_table    VARCHAR(24) NOT NULL CHECK (object_table IN ('star_systems', 'rogue_planets', 'interstellar_comets')),
    object_id       BIGINT UNSIGNED NOT NULL,
    exited          TINYINT(1) NOT NULL,
    duration_years  DOUBLE NOT NULL,
    computed_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (object_table, object_id),
    KEY idx_sector_paths_sector (sector_id),
    CONSTRAINT fk_sector_paths_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_path_knots (
    id        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    path_id   BIGINT UNSIGNED NOT NULL,
    position  INT NOT NULL,
    t_years   DOUBLE NOT NULL,
    x_pc      DOUBLE NOT NULL,
    y_pc      DOUBLE NOT NULL,
    z_pc      DOUBLE NOT NULL,
    vx_kms    DOUBLE NOT NULL,
    vy_kms    DOUBLE NOT NULL,
    vz_kms    DOUBLE NOT NULL,
    UNIQUE (path_id, position),
    CONSTRAINT fk_sector_path_knots_path
        FOREIGN KEY (path_id) REFERENCES sector_paths(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS generation_runs (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    command              VARCHAR(32) NOT NULL,
    run_seed             BINARY(16),
    galaxy_seed          BINARY(16),
    version_key          CHAR(22) NOT NULL,
    planetgen_version    VARCHAR(32) NOT NULL,
    python_version       VARCHAR(16) NOT NULL,
    platform             VARCHAR(64) NOT NULL,
    started_at           TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    finished_at          TIMESTAMP(3) NULL,
    outcome              VARCHAR(16),
    KEY idx_generation_runs_started_at (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS generation_run_arguments (
    run_id       BIGINT UNSIGNED NOT NULL,
    position     INT NOT NULL,
    value        VARCHAR(1024) NOT NULL,
    PRIMARY KEY (run_id, position),
    CONSTRAINT fk_generation_run_arguments_run FOREIGN KEY (run_id) REFERENCES generation_runs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS phenomenon_scatter (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ring_index           INT NOT NULL,
    layer_index          SMALLINT NOT NULL,
    ring_slot_index      INT NOT NULL,
    kind                 VARCHAR(24) NOT NULL,
    subtype              VARCHAR(16),
    position_x_mpc       BIGINT NOT NULL,
    position_y_mpc       BIGINT NOT NULL,
    position_z_mpc       BIGINT NOT NULL,
    velocity_x_kms       DOUBLE,
    velocity_y_kms       DOUBLE,
    velocity_z_kms       DOUBLE,
    seed                 BIGINT UNSIGNED NOT NULL,
    built_at             TIMESTAMP NULL,
    epoch_unix           DOUBLE,  -- v69 (GEN.137): when the position holds, see the header comment
    KEY idx_phenomenon_scatter_address (ring_index, layer_index, ring_slot_index),
    CONSTRAINT chk_phenomenon_scatter_kind CHECK (kind IN (
        'black-hole', 'neutron-star', 'planetary-nebula', 'supernova-remnant', 'hypervelocity-star', 'quasar'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS phenomenon_scatter_classes (
    kind     VARCHAR(24) NOT NULL,
    subtype  VARCHAR(16) NOT NULL DEFAULT '',
    placed   BIGINT UNSIGNED NOT NULL DEFAULT 0,
    built    BIGINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (kind, subtype)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS id_blocks (
    table_name  VARCHAR(64) NOT NULL PRIMARY KEY,
    next_id     BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS species (
    id                       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                     VARCHAR(255) NOT NULL,
    homeworld_planet_id      BIGINT UNSIGNED NOT NULL,
    star_system_id           BIGINT UNSIGNED NOT NULL,
    life_chemical            VARCHAR(64),
    life_stage               VARCHAR(32) NOT NULL,
    build                    VARCHAR(16) NOT NULL,
    climate                  VARCHAR(16) NOT NULL,
    size                     VARCHAR(16) NOT NULL,
    civilization_age_years   DOUBLE,
    era                      VARCHAR(16),
    spacefaring              TINYINT(1) NOT NULL DEFAULT 0 CHECK (spacefaring IN (0, 1)),
    created_at               TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_species_name (name),
    UNIQUE KEY uq_species_homeworld (homeworld_planet_id),
    KEY idx_species_system (star_system_id),
    KEY idx_species_spacefaring (spacefaring),
    CONSTRAINT chk_species_life_stage CHECK (life_stage IN ('multicellularity', 'technological_civilization')),
    CONSTRAINT fk_species_planet
        FOREIGN KEY (homeworld_planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    CONSTRAINT fk_species_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS polities (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(255) NOT NULL,
    species_id          BIGINT UNSIGNED NOT NULL,
    capital_system_id   BIGINT UNSIGNED NOT NULL,
    government          VARCHAR(32) NOT NULL,
    color               CHAR(7) NOT NULL,
    reach_ly            DOUBLE NOT NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_polities_name (name),
    UNIQUE KEY uq_polities_species (species_id),
    KEY idx_polities_capital (capital_system_id),
    CONSTRAINT fk_polities_species
        FOREIGN KEY (species_id) REFERENCES species(id) ON DELETE CASCADE,
    CONSTRAINT fk_polities_capital
        FOREIGN KEY (capital_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_owners (
    star_system_id   BIGINT UNSIGNED PRIMARY KEY,
    polity_id        BIGINT UNSIGNED NOT NULL,
    distance_ly      DOUBLE NOT NULL,
    KEY idx_system_owners_polity (polity_id),
    CONSTRAINT fk_system_owners_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_system_owners_polity
        FOREIGN KEY (polity_id) REFERENCES polities(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS population_state (
    id                     TINYINT UNSIGNED PRIMARY KEY,
    scanned_planet_id      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    CHECK (id = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE OR REPLACE VIEW sector_objects AS
    SELECT
        'star'                          AS object_type,
        s.id                            AS object_id,
        s.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        s.name                          AS name,
        s.star_type                     AS summary,
        NULL                            AS orbital_index
    FROM stars s
    JOIN star_systems ss ON ss.id = s.star_system_id
    UNION ALL
    SELECT
        'planet'                        AS object_type,
        p.id                            AS object_id,
        p.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        p.name                          AS name,
        COALESCE(p.planet_class, p.body_type) AS summary,
        p.orbital_index                 AS orbital_index
    FROM planets p
    JOIN star_systems ss ON ss.id = p.star_system_id
    UNION ALL
    SELECT
        'moon'                          AS object_type,
        m.id                            AS object_id,
        m.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        m.name                          AS name,
        COALESCE(m.planet_class, m.body_type) AS summary,
        m.orbital_index                 AS orbital_index
    FROM moons m
    JOIN star_systems ss ON ss.id = m.star_system_id
    UNION ALL
    SELECT
        'asteroid_belt'                 AS object_type,
        ab.id                           AS object_id,
        ab.star_system_id               AS star_system_id,
        ss.sector_id                    AS sector_id,
        'Asteroid Belt'                 AS name,
        ab.density                      AS summary,
        ab.orbital_index                AS orbital_index
    FROM asteroid_belts ab
    JOIN star_systems ss ON ss.id = ab.star_system_id
    UNION ALL
    SELECT
        'comet'                         AS object_type,
        c.id                            AS object_id,
        c.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        c.name                          AS name,
        c.orbit_type                    AS summary,
        NULL                            AS orbital_index
    FROM comets c
    JOIN star_systems ss ON ss.id = c.star_system_id;
SET FOREIGN_KEY_CHECKS = 1;
