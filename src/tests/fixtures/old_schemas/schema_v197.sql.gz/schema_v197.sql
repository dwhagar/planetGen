SET FOREIGN_KEY_CHECKS = 0;
CREATE TABLE IF NOT EXISTS schema_migrations (
    version      INT NOT NULL PRIMARY KEY,
    applied_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS alembic_version (
    version_num  VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sectors (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(255) NOT NULL,
    edge_mpc            DOUBLE NOT NULL,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    galactic_radius_pc  DOUBLE,
    shell_index         INT,
    band_index          INT,
    wedge_index         INT,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BIGINT UNSIGNED,
    max_mass_kg                 DOUBLE NULL,  -- v102 (DB.55)
    max_mass_id                 BINARY(12) NULL,  -- v102 (DB.55)
    storage_checksum            BINARY(32) NULL,  -- v115 (DB.44)
    parity_dirty                TINYINT NOT NULL DEFAULT 1,  -- v115 (DB.44)
    leaf_digest                 BINARY(32) NULL,  -- v120 (DB.49)
    generator_epoch             SMALLINT UNSIGNED NULL,  -- v121 (DB.16)
    run_id                      BIGINT UNSIGNED NULL,  -- v121 (DB.16)
    density_multiplier_used     DECIMAL(10,4) NULL,  -- v125 (DB.60)
    override_id                 BIGINT UNSIGNED NULL,  -- v125 (DB.60)
    UNIQUE KEY uq_sectors_uid (uid),
    CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    UNIQUE KEY uq_sectors_address (shell_index, band_index, wedge_index),
    KEY idx_sectors_galactic_radius_pc (galactic_radius_pc),
    KEY idx_sectors_name (name),
    FULLTEXT KEY ft_sectors_name (name),
    KEY idx_sectors_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_sectors_modified_at (modified_at),
    KEY idx_sectors_run (run_id),
    CONSTRAINT fk_sectors_run FOREIGN KEY (run_id) REFERENCES generation_runs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_shape (
    id                          BIGINT UNSIGNED PRIMARY KEY CHECK (id = 1),
    disk_scale_length_pc        DOUBLE NOT NULL,
    disk_scale_height_pc        DOUBLE NOT NULL,
    bulge_scale_radius_pc       DOUBLE NOT NULL,
    bulge_amplitude             DOUBLE NOT NULL,
    arm_count                   INT NOT NULL,
    pitch_angle_rad             DOUBLE NOT NULL,
    arm_amplitude               DOUBLE NOT NULL,
    arm_level                   DOUBLE NOT NULL DEFAULT 1,  -- v81 (ADM.49): see header comment
    nuclear_amplitude           DOUBLE NOT NULL DEFAULT 0,  -- v99 (GEN.280): see header comment
    spiral_reference_radius_pc  DOUBLE NOT NULL,
    spiral_reference_angle_rad  DOUBLE NOT NULL,
    k_norm                      DOUBLE NOT NULL,
    edge_pc                     DOUBLE NOT NULL,
    expected_system_count_at_density_1  DOUBLE NOT NULL,
    outer_shell_index            INT NOT NULL,
    reach_shell_index            INT NOT NULL DEFAULT 65535,  -- v93 (GEN.233), see header comment
    cell_star_ceiling            DOUBLE NOT NULL DEFAULT 5000,
    fill_luminosity_cap_sol      DOUBLE NOT NULL DEFAULT 100,
    core_min_luminosity_sol      DOUBLE,
    core_mass_limit_sol          DOUBLE,
    halo_min_luminosity_sol      DOUBLE NOT NULL DEFAULT 500,
    pinned_stellar_mass_solar    DOUBLE,
    family                          VARCHAR(16) NOT NULL DEFAULT 'spiral',
    bar_present                     TINYINT,
    bar_axis_ratio_b                DOUBLE,
    bar_axis_ratio_c                DOUBLE,
    bar_angle_rad                   DOUBLE,
    thick_disk_amplitude            DOUBLE,
    spheroid_amplitude              DOUBLE NOT NULL DEFAULT 0,
    spheroid_sersic_n               DOUBLE NOT NULL DEFAULT 0,
    spheroid_effective_radius_pc    DOUBLE NOT NULL DEFAULT 0,
    spheroid_axis_ratio_b           DOUBLE NOT NULL DEFAULT 1,
    spheroid_axis_ratio_c           DOUBLE NOT NULL DEFAULT 1,
    spheroid_orientation_1_rad      DOUBLE NOT NULL DEFAULT 0,
    spheroid_orientation_2_rad      DOUBLE NOT NULL DEFAULT 0,
    spheroid_orientation_3_rad      DOUBLE NOT NULL DEFAULT 0,
    body_clump_share                DOUBLE NOT NULL DEFAULT 0,
    bright_star_min_luminosity_sol  DOUBLE,
    bright_star_seed                BIGINT UNSIGNED,
    bright_star_mass_limit_sol      DOUBLE,
    phenomenon_scatter_seed         BIGINT UNSIGNED,
    phenomenon_min_mass_solar       DOUBLE,
    galaxy_seed                     BINARY(16),
    version_key                     CHAR(22),
    planetgen_version               VARCHAR(32),
    python_version                  VARCHAR(16),
    platform                        VARCHAR(64),
    density_ratio_avg               DOUBLE,
    density_ratio_samples           BIGINT UNSIGNED NOT NULL DEFAULT 0,
    generator_epoch                 SMALLINT UNSIGNED NULL,
    fp_spec                         SMALLINT UNSIGNED NULL,
    battery_digest                  CHAR(64) NULL,
    battery_cases                   JSON NULL,
    CONSTRAINT chk_galaxy_shape_cell_star_ceiling CHECK (cell_star_ceiling >= 1),  -- v100 (GEN.281)
    CONSTRAINT chk_galaxy_shape_scatter_limits CHECK (  -- v101 (DB.54)
        halo_min_luminosity_sol >= 50 AND (core_min_luminosity_sol IS NULL OR core_min_luminosity_sol > 0)
        AND (core_mass_limit_sol IS NULL OR core_mass_limit_sol > 0)),
    CONSTRAINT chk_galaxy_shape_family CHECK (  -- v117 (DB.66)
        family IN ('spiral', 'lenticular', 'elliptical', 'irregular', 'dwarf_spheroid')),
    CONSTRAINT chk_galaxy_shape_bar_axis_ratio_b CHECK (bar_axis_ratio_b > 0 AND bar_axis_ratio_b <= 1),  -- v117 (DB.66), NULL passes
    CONSTRAINT chk_galaxy_shape_bar_axis_ratio_c CHECK (bar_axis_ratio_c > 0 AND bar_axis_ratio_c <= 1),
    CONSTRAINT chk_galaxy_shape_thick_disk_amplitude CHECK (thick_disk_amplitude >= 0),
    CONSTRAINT chk_galaxy_shape_spheroid_amplitude CHECK (spheroid_amplitude >= 0),
    CONSTRAINT chk_galaxy_shape_spheroid_sersic_n CHECK (spheroid_sersic_n >= 0),
    CONSTRAINT chk_galaxy_shape_spheroid_effective_radius CHECK (spheroid_effective_radius_pc >= 0),
    CONSTRAINT chk_galaxy_shape_spheroid_axis_ratio_b CHECK (spheroid_axis_ratio_b > 0 AND spheroid_axis_ratio_b <= 1),
    CONSTRAINT chk_galaxy_shape_spheroid_axis_ratio_c CHECK (spheroid_axis_ratio_c > 0 AND spheroid_axis_ratio_c <= 1),
    CONSTRAINT chk_galaxy_shape_body_clump_share CHECK (body_clump_share BETWEEN 0 AND 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_shape_pins (
    name                        VARCHAR(40) NOT NULL PRIMARY KEY,
    value                       DOUBLE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_shell (
    shell_index       INT NOT NULL PRIMARY KEY,
    high_band_index   INT NOT NULL,
    cell_count        BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_block_stats (
    m                 INT UNSIGNED NOT NULL,
    shell_index       INT NOT NULL,
    band_index        INT NOT NULL,
    wedge_index       INT NOT NULL,
    sector_count      INT UNSIGNED NOT NULL,
    systems           BIGINT UNSIGNED NOT NULL,
    expected_systems  DOUBLE NOT NULL,
    stars             BIGINT UNSIGNED NOT NULL,
    age_sum           DOUBLE NOT NULL,
    luminosity_sol    DOUBLE NOT NULL,
    habitable_worlds  BIGINT UNSIGNED NOT NULL DEFAULT 0,   -- v139 (MAP.143)
    mass_sum_kg       DOUBLE NOT NULL DEFAULT 0,   -- v168 (DB.108): the summed `sector_stats.total_mass_kg` of its generated sectors
    PRIMARY KEY (m, shell_index, band_index, wedge_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_block_lights (
    m                    INT UNSIGNED NOT NULL,
    shell_index          INT NOT NULL,
    band_index           INT NOT NULL,
    wedge_index          INT NOT NULL,
    star_count           BIGINT UNSIGNED NOT NULL,
    star_luminosity_sol  DOUBLE NOT NULL,
    star_lpx              DOUBLE NOT NULL,
    star_lpy              DOUBLE NOT NULL,
    star_lpz              DOUBLE NOT NULL,
    star_lt              DOUBLE NOT NULL,
    point_count          BIGINT UNSIGNED NOT NULL,
    point_luminosity_sol DOUBLE NOT NULL,
    point_lpx             DOUBLE NOT NULL,
    point_lpy             DOUBLE NOT NULL,
    point_lpz             DOUBLE NOT NULL,
    PRIMARY KEY (m, shell_index, band_index, wedge_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS region_stats (
    shell_index       INT NOT NULL,
    band_index        INT NOT NULL,
    wedge_index       INT NOT NULL,
    sector_count      INT UNSIGNED NOT NULL,
    capacity          INT UNSIGNED NOT NULL,
    clump_count       INT UNSIGNED NOT NULL,
    extent_x_pc       DOUBLE NOT NULL,
    extent_y_pc       DOUBLE NOT NULL,
    extent_z_pc       DOUBLE NOT NULL,
    extent_radius_pc  DOUBLE NOT NULL,
    mass_sum_kg       DOUBLE NOT NULL DEFAULT 0,   -- v168 (DB.108): the summed `sector_stats.total_mass_kg` of its generated sectors
    PRIMARY KEY (shell_index, band_index, wedge_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orbit_simulation_state (
    id               BIGINT UNSIGNED PRIMARY KEY CHECK (id = 1),
    last_updated_at  TIMESTAMP NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_configs (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    habitable_world   TINYINT(1) CHECK (habitable_world IN (0, 1)),
    asteroid_belt     TINYINT(1) CHECK (asteroid_belt IN (0, 1)),
    comets            TINYINT(1) CHECK (comets IN (0, 1)),          -- v50
    large_star        TINYINT(1) CHECK (large_star IN (0, 1)),
    moons             TINYINT(1) CHECK (moons IN (0, 1)),
    max_planets       TINYINT(1) CHECK (max_planets IN (0, 1)),
    planets           TINYINT(1) CHECK (planets IN (0, 1)),
    star_type         VARCHAR(64),
    name              VARCHAR(255),
    age               VARCHAR(16) CHECK (age IN ('young', 'old')),
    intelligent_life  TINYINT(1) CHECK (intelligent_life IN (0, 1)),
    binary_system     TINYINT(1) CHECK (binary_system IN (0, 1)),
    wide_binary       TINYINT(1) CHECK (wide_binary IN (0, 1)),     -- v50
    num_orbits        INT,
    prevalence_habitable_world DOUBLE NOT NULL DEFAULT 0,  -- v54
    prevalence_asteroid_belt DOUBLE NOT NULL DEFAULT 0,
    prevalence_comets DOUBLE NOT NULL DEFAULT 0,
    prevalence_large_star DOUBLE NOT NULL DEFAULT 0,
    prevalence_moons DOUBLE NOT NULL DEFAULT 0,
    prevalence_max_planets DOUBLE NOT NULL DEFAULT 0,
    prevalence_intelligent_life DOUBLE NOT NULL DEFAULT 0,
    prevalence_binary_system DOUBLE NOT NULL DEFAULT 0,
    prevalence_wide_binary DOUBLE NOT NULL DEFAULT 0,
    prevalence_planets DOUBLE NOT NULL DEFAULT 0,
    stars             TINYINT UNSIGNED,  -- v134 (GEN.267): the forced number of stars, NULL when left to chance
    max_stars         TINYINT UNSIGNED NOT NULL DEFAULT 12,  -- v134: the cap on the star count
    prevalence_multi_star DOUBLE NOT NULL DEFAULT 0  -- v134: the chance of five or more stars, percent from usual
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_config_slots (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    config_id     BIGINT UNSIGNED NOT NULL,
    orbit_index   INT NOT NULL,
    type          VARCHAR(16) CHECK (type IN ('planet', 'asteroid_belt')),
    planet_class  VARCHAR(16),
    moons         INT,
    CONSTRAINT fk_system_config_slots_config
        FOREIGN KEY (config_id) REFERENCES system_configs(id) ON DELETE CASCADE,
    KEY idx_system_config_slots_config_id (config_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS star_systems (
    id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id              BIGINT UNSIGNED,
    system_config_id       BIGINT UNSIGNED NOT NULL,
    name                   VARCHAR(255) NOT NULL,
    position_x_mpc          DOUBLE,
    position_y_mpc          DOUBLE,
    position_z_mpc          DOUBLE,
    galaxy_x_pc          DOUBLE,
    galaxy_y_pc          DOUBLE,
    galaxy_z_pc          DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(galaxy_x_pc) < 262144 AND ABS(galaxy_y_pc) < 262144 AND ABS(galaxy_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((galaxy_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((galaxy_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((galaxy_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((galaxy_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((galaxy_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((galaxy_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((galaxy_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((galaxy_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((galaxy_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    KEY idx_star_systems_cell (cell_key, galaxy_x_pc, galaxy_y_pc, galaxy_z_pc),
    quadrant                VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    location                TEXT,
    is_binary              TINYINT(1) NOT NULL DEFAULT 0 CHECK (is_binary IN (0, 1)),
    binary_configuration   VARCHAR(8) CHECK (binary_configuration IN ('close', 'wide')),
    binary_separation_km            DOUBLE,
    binary_eccentricity              DOUBLE,
    binary_periapsis_km              DOUBLE,
    binary_apoapsis_km               DOUBLE,
    binary_type                     VARCHAR(64),
    binary_temperature_k            DOUBLE,
    binary_radius_km                DOUBLE,
    binary_effective_mass_kg        DOUBLE,
    binary_effective_luminosity_w   DOUBLE,
    binary_age_gy                   DOUBLE,
    binary_lifespan_gy              DOUBLE,  -- NULL = float('inf')
    binary_habitable_zone_inner_km  DOUBLE,
    binary_habitable_zone_outer_km  DOUBLE,
    binary_system_perimeter_km      DOUBLE,
    binary_heliosphere_radius_km    DOUBLE,
    binary_galactic_orbital_period_gy   DOUBLE,
    binary_galactic_orbital_phase_deg          DOUBLE,  -- v13, see header comment
    binary_galactic_min_update_interval_years  DOUBLE,  -- v13, see header comment
    binary_mutual_orbital_period_years         DOUBLE,
    binary_mutual_orbital_speed_kms            DOUBLE,
    binary_mutual_orbital_inclination_deg      DOUBLE,
    binary_mutual_orbital_ascending_node_deg   DOUBLE,
    binary_mutual_orbital_phase_deg            DOUBLE,
    binary_epoch_unix                          DOUBLE,  -- v66 (GEN.106)
    binary_next_update_due                     DOUBLE,
    binary_mutual_min_update_interval_years    DOUBLE,
    binary_mutual_position_x_km   DOUBLE,
    binary_mutual_position_y_km   DOUBLE,
    binary_mutual_position_z_km   DOUBLE,
    binary_primary_position_x_km    DOUBLE,
    binary_primary_position_y_km    DOUBLE,
    binary_primary_position_z_km    DOUBLE,
    binary_secondary_position_x_km  DOUBLE,
    binary_secondary_position_y_km  DOUBLE,
    binary_secondary_position_z_km  DOUBLE,
    binary_secondary_mass_fraction  DOUBLE,
    binary_planetary_wobble_x_km    DOUBLE,
    binary_planetary_wobble_y_km    DOUBLE,
    binary_planetary_wobble_z_km    DOUBLE,
    system_flavor_text   TEXT,
    runaway_class        VARCHAR(16),
    runaway_speed_kms    DOUBLE,
    velocity_x_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms       DOUBLE NOT NULL DEFAULT 0,
    epoch_unix           DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due      DOUBLE,
    schema_version       INT NOT NULL DEFAULT 1,
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_star_systems_uid (uid),
    CONSTRAINT fk_star_systems_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    CONSTRAINT fk_star_systems_config
        FOREIGN KEY (system_config_id) REFERENCES system_configs(id),
    KEY idx_star_systems_sector_id (sector_id),
    KEY idx_star_systems_next_update_due (next_update_due),
    KEY idx_star_systems_binary_next_update_due (binary_next_update_due),
    KEY idx_star_systems_system_config_id (system_config_id),
    KEY idx_star_systems_name (name),
    FULLTEXT KEY ft_star_systems_name (name),
    KEY idx_star_systems_modified_at (modified_at),
    KEY idx_star_systems_quadrant (quadrant, name, id),
    KEY idx_star_systems_binary_name (is_binary, name, id),
    CONSTRAINT fk_star_systems_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_star_systems_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS stars (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id            BIGINT UNSIGNED NOT NULL,
    role                      VARCHAR(16) NOT NULL CHECK (role IN ('primary', 'secondary', 'single', 'member')),  -- v133 (GEN.630): 'member'
    name                      VARCHAR(255) NOT NULL,
    star_type                 VARCHAR(64) NOT NULL,   -- Star.type, e.g. "G2V Yellow Main Sequence Star"
    yerkes_class              VARCHAR(16) NOT NULL,
    mass_kg                   DOUBLE NOT NULL,
    radius_km                 DOUBLE NOT NULL,
    temperature_k             DOUBLE NOT NULL,
    luminosity_w              DOUBLE NOT NULL,
    age_gy                    DOUBLE NOT NULL,
    lifespan_gy               DOUBLE,            -- NULL = float('inf'), white dwarfs
    habitable_zone_inner_km   DOUBLE NOT NULL,
    habitable_zone_outer_km   DOUBLE NOT NULL,
    system_perimeter_km       DOUBLE NOT NULL,
    heliosphere_radius_km     DOUBLE NOT NULL,
    galactic_orbital_period_gy    DOUBLE NOT NULL,
    galactic_orbital_phase_deg          DOUBLE NOT NULL,  -- v13, see header comment
    galactic_min_update_interval_years  DOUBLE NOT NULL,  -- v13, see header comment
    wide_binary_a_crit_km               DOUBLE,
    reflex_offset_x_km       DOUBLE,
    reflex_offset_y_km       DOUBLE,
    reflex_offset_z_km       DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    log_lx_lbol                 DOUBLE,
    l_xuv_w                     DOUBLE,
    xuv_saturated               BOOLEAN,
    flare_n33_per_yr            DOUBLE,
    flare_alpha                 DOUBLE,
    xuv_fluence_j               DOUBLE,
    lethal_event_rate_per_gyr   DOUBLE,
    uid                   BINARY(12),
    metallicity_fe_h      DOUBLE,
    parent_node_id              SMALLINT NULL,  -- v104 (DB.53)
    slot                        TINYINT UNSIGNED NULL,  -- v133 (GEN.630): 0 or 1, the child of its parent node this star is
    state                       VARCHAR(16) NULL,  -- v104 (DB.53)
    flags                       SMALLINT UNSIGNED NULL,  -- v104 (DB.53)
    offset_x_au                 DOUBLE NULL,  -- v104 (DB.53)
    offset_y_au                 DOUBLE NULL,  -- v104 (DB.53)
    offset_z_au                 DOUBLE NULL,  -- v104 (DB.53)
    velocity_x_kms              DOUBLE NULL,  -- v104 (DB.53)
    velocity_y_kms              DOUBLE NULL,  -- v104 (DB.53)
    velocity_z_kms              DOUBLE NULL,  -- v104 (DB.53)
    decay_age_yr                DOUBLE NULL,  -- v104 (DB.53)
    epoch_unix                  DOUBLE NULL,  -- v104 (DB.53)
    disk_kind                   VARCHAR(16) NULL,  -- v104 (DB.53)
    disk_mass_solar             DOUBLE NULL,  -- v104 (DB.53)
    disk_inner_au               DOUBLE NULL,  -- v104 (DB.53)
    disk_outer_au               DOUBLE NULL,  -- v104 (DB.53)
    cluster_id                  BIGINT UNSIGNED NULL,  -- v127 (DB.61)
    snow_line_km                DOUBLE NOT NULL,  -- v132 (GEN.458): this star's own snow line, drawn once around the 170 K blackbody position
    uv_c_share                  DOUBLE NULL,  -- v145 (GEN.443): the UV-C share of the star's blackbody, drawn once (log-uniform 0.1 to 1), NULL for a remnant and for a row saved before v145
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'system',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    UNIQUE KEY uq_stars_uid (uid),
    KEY idx_stars_parent (parent_type, parent_id),
    CONSTRAINT chk_stars_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    CONSTRAINT fk_stars_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    KEY idx_stars_star_system_id (star_system_id),
    KEY idx_stars_name (name),
    FULLTEXT KEY ft_stars_name (name),
    KEY idx_stars_yerkes_class (yerkes_class),
    KEY idx_stars_radius_km (radius_km),
    KEY idx_stars_star_type (star_type),
    KEY idx_stars_cluster (cluster_id),
    CONSTRAINT fk_stars_cluster
        FOREIGN KEY (cluster_id) REFERENCES galaxy_components(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planets (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id            BIGINT UNSIGNED NOT NULL,
    star_id                   BIGINT UNSIGNED,
    orbital_index             INT NOT NULL,
    body_type                 VARCHAR(4) NOT NULL CHECK (body_type IN ('t', 'g')),
    name                      VARCHAR(255) NOT NULL,
    planet_class              VARCHAR(16),
    distance_km               DOUBLE NOT NULL,   -- from the star
    radius_km                 DOUBLE NOT NULL,
    mass_kg                   DOUBLE NOT NULL,
    volume_km3                DOUBLE NOT NULL,   -- derived, stored not recomputed
    period_years              DOUBLE NOT NULL,   -- derived, stored not recomputed
    zone                      VARCHAR(4) CHECK (zone IN ('h', 'e', 'c')),
    description               TEXT,
    gravity_g                 DOUBLE,
    surface_temperature_k     DOUBLE,
    density_g_cm3             DOUBLE,
    atmosphere                TEXT,
    atm_density               DOUBLE,
    atm_molar_density         DOUBLE,
    atmospheric_pressure_pa   DOUBLE,
    composition               TEXT,            -- descriptive string (contrast asteroid_belt_composition)
    scale_height_km           DOUBLE,
    hill_radius_km            DOUBLE,
    min_orbit_distance_km     DOUBLE,
    habitable_zone_inner_km   DOUBLE NOT NULL,   -- copied from host star at generation time
    habitable_zone_outer_km   DOUBLE NOT NULL,
    flavor_text_count         INT NOT NULL DEFAULT 0,
    life_stage                VARCHAR(32),      -- v110 (DB.50): a MILESTONE_KEYS key, NULL before any milestone
    evolutionary_pace         VARCHAR(16),      -- v110: the pace life evolves at (fast, normal, slow), drawn once, set with any life chemistry (v143)
    life_milestone_age_gyr    DOUBLE,           -- v110: the age of that milestone, Gy
    life_system_age_gyr       DOUBLE,           -- v110: the age of the system the timeline was written at, Gy
    life_age_abiogenesis_gyr  DOUBLE,           -- v156 (DB.100): the age the pace reaches abiogenesis, Gy
    life_age_photosynthesis_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches photosynthesis, Gy
    life_age_complex_cells_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches complex cells, Gy
    life_age_multicellularity_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches multicellularity, Gy
    life_age_technological_civilization_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches technological civilization, Gy
    flavor_key                VARCHAR(32),      -- v110: which flavour line (replaces flavor_text)
    orbital_inclination_deg     DOUBLE NOT NULL,
    orbital_ascending_node_deg  DOUBLE NOT NULL,
    eccentricity                DOUBLE NOT NULL DEFAULT 0,   -- v159 (GEN.727): of the orbit the body was generated on (distance_km is its semi-major axis)
    position_x_km               DOUBLE NOT NULL,
    position_y_km               DOUBLE NOT NULL,
    position_z_km               DOUBLE NOT NULL,
    orbital_speed_kms           DOUBLE NOT NULL,
    velocity_x_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms              DOUBLE NOT NULL DEFAULT 0,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    min_update_interval_years   DOUBLE NOT NULL,  -- v12, see header comment
    rotation_period_hours       DOUBLE NOT NULL,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    mantle_redox                VARCHAR(16) CHECK (mantle_redox IN ('reduced', 'intermediate', 'oxidized')),
    mantle_delta_iw             DOUBLE,
    magnetic_moment_a_m2        DOUBLE,
    dipole_class                VARCHAR(16) CHECK (dipole_class IN ('none', 'weak', 'earth-like', 'strong', 'multipolar')),
    induced_moment_a_m2         DOUBLE,
    magnetopause_rp             DOUBLE,
    xuv_flux_earth              DOUBLE,
    xuv_exposure_index          DOUBLE,
    flare_irradiation_index     DOUBLE,
    water_mass_fraction         DOUBLE,
    hydrosphere                 VARCHAR(20) CHECK (hydrosphere IN ('dry', 'vapour', 'ice', 'ice-covered ocean', 'surface ocean', 'brine seep', 'hycean')),
    ocean_fraction              DOUBLE,
    land_fraction               DOUBLE,
    ocean_depth_km              DOUBLE,
    ice_shell_km                DOUBLE,
    hp_ice_km                   DOUBLE,
    ocean_class                 VARCHAR(16) CHECK (ocean_class IN ('ice-sealed', 'chloride brine', 'acid sulfate', 'soda', 'neutral')),
    ocean_ph                    DOUBLE,
    water_activity              DOUBLE,
    phosphorus                  VARCHAR(8) CHECK (phosphorus IN ('high', 'limited', 'starved')),
    surface_dose_msv_yr         DOUBLE,
    dose_gcr_msv_yr             DOUBLE,
    dose_sep_msv_yr             DOUBLE,
    dose_ground_msv_yr          DOUBLE,
    dose_belt_msv_yr            DOUBLE,  -- v187 (GEN.983): the dose a moon takes from its parent's trapped-particle belts, mSv/yr (0 for a planet)
    dose_helio_mult             DOUBLE,
    uv_surface_index            DOUBLE,
    ozone_loss_flag             BOOLEAN,
    phi4                        DOUBLE,
    phi4_pressure               DOUBLE,
    phi4_temperature            DOUBLE,
    phi4_air                    DOUBLE,
    phi4_water                  DOUBLE,
    phi4_suitability            DOUBLE,
    phi4_radiation              DOUBLE,
    tier_pressure               TINYINT,
    tier_temperature            TINYINT,
    tier_air                    TINYINT,
    tier_water                  TINYINT,
    tier_suitability            TINYINT,
    tier_radiation              TINYINT,
    life_microbial              TINYINT UNSIGNED NULL,  -- v150 (GEN.649): 0 none to 9 abundant, from the evolutionary path and the surface
    life_flora                  TINYINT UNSIGNED NULL,  -- v150
    life_fauna                  TINYINT UNSIGNED NULL,  -- v150
    life_sentient               TINYINT UNSIGNED NULL,  -- v150
    l_solv                      DOUBLE,
    l_chem                      DOUBLE,
    l_ener                      DOUBLE,
    l_rad                       DOUBLE,
    eq_body                     TINYINT,
    eq_body_kind                TINYINT,
    eq_body_rec                 TINYINT,
    eq_body_rec_kind            TINYINT,
    eq_rad_suit                 TINYINT,
    eq_rad_suit_rec             TINYINT,
    eq_mobility                 TINYINT,
    eq_dust                     TINYINT,
    eq_gas_filter               TINYINT,
    eq_co2_scrub                TINYINT,
    eq_supply                   TINYINT,
    eq_supply_rec               TINYINT,
    eq_shelter                  TINYINT,
    eq_shelter_rec              TINYINT,
    shelter_column_g_cm2        DOUBLE,
    outside_hours               DOUBLE,
    band1_mean_k                DOUBLE,  -- v196 (GEN.1108): the climate of the body in seven bands of latitude (`physics/latitude_bands.py`): `band1` is the north pole, `band7` the south pole (a world locked to its star: the day centre to the night centre)
    band1_swing_k               DOUBLE,
    band1_day_hours             DOUBLE,
    band1_night_hours           DOUBLE,
    band1_longest_day_days      DOUBLE,
    band1_longest_night_days    DOUBLE,
    band1_state                 VARCHAR(24),
    band2_mean_k                DOUBLE,
    band2_swing_k               DOUBLE,
    band2_day_hours             DOUBLE,
    band2_night_hours           DOUBLE,
    band2_longest_day_days      DOUBLE,
    band2_longest_night_days    DOUBLE,
    band2_state                 VARCHAR(24),
    band3_mean_k                DOUBLE,
    band3_swing_k               DOUBLE,
    band3_day_hours             DOUBLE,
    band3_night_hours           DOUBLE,
    band3_longest_day_days      DOUBLE,
    band3_longest_night_days    DOUBLE,
    band3_state                 VARCHAR(24),
    band4_mean_k                DOUBLE,
    band4_swing_k               DOUBLE,
    band4_day_hours             DOUBLE,
    band4_night_hours           DOUBLE,
    band4_longest_day_days      DOUBLE,
    band4_longest_night_days    DOUBLE,
    band4_state                 VARCHAR(24),
    band5_mean_k                DOUBLE,
    band5_swing_k               DOUBLE,
    band5_day_hours             DOUBLE,
    band5_night_hours           DOUBLE,
    band5_longest_day_days      DOUBLE,
    band5_longest_night_days    DOUBLE,
    band5_state                 VARCHAR(24),
    band6_mean_k                DOUBLE,
    band6_swing_k               DOUBLE,
    band6_day_hours             DOUBLE,
    band6_night_hours           DOUBLE,
    band6_longest_day_days      DOUBLE,
    band6_longest_night_days    DOUBLE,
    band6_state                 VARCHAR(24),
    band7_mean_k                DOUBLE,
    band7_swing_k               DOUBLE,
    band7_day_hours             DOUBLE,
    band7_night_hours           DOUBLE,
    band7_longest_day_days      DOUBLE,
    band7_longest_night_days    DOUBLE,
    band7_state                 VARCHAR(24),
    temp_mean_swing_k           DOUBLE,  -- v182 (GEN.848): the day and night swing of the whole surface, peak to peak, kelvin of difference
    outside_hours_day           DOUBLE,  -- v187 (GEN.768): the hours of one local day a person can be outside in the listed equipment
    outside_hours_limit         VARCHAR(16),  -- v187 (GEN.768): what sets them: daylight, dose, heat, cold, air, uv or vehicle
    day_night_state             VARCHAR(24),  -- v188 (GEN.1097): the state of its day and night: day and night, tidally locked, spin-orbit resonance, non-rotating, polar day and night or no solid surface
    night_hours                 DOUBLE,  -- v188 (GEN.1097): hours of night in one solar day at the equator, NULL for a world that turns once an orbit
    days_per_year               DOUBLE,  -- v188 (GEN.1097): solar days in one orbit round the star, NULL for a world that turns once an orbit
    roundness_ratio             DOUBLE,  -- v197 (GEN.1159): the mean radius over the round radius, 1 or more is round and less is not
    yield_strength_pa           DOUBLE,  -- v197 (GEN.1159): the whole-body strength of the material mix of the body, Pa, drawn from the range of each material (GEN.1178)
    binding_energy_j            DOUBLE,  -- v197 (GEN.1159): the energy that assembling the body releases, J
    energy_flux_w_m2            DOUBLE,
    flux_variation              DOUBLE,
    reflex_offset_x_km       DOUBLE,
    reflex_offset_y_km       DOUBLE,
    reflex_offset_z_km       DOUBLE,
    uid                   BINARY(12),
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'star',  -- v102 (DB.55), v140 (DB.73): wider
    parent_id                   BIGINT UNSIGNED NULL,  -- v102 (DB.55)
    dynamical_state             VARCHAR(8) NOT NULL DEFAULT 'bound',  -- v102 (DB.55)
    host_node_id                SMALLINT NULL,  -- v104 (DB.53): the orbit node the planet orbits (NULL: its star)
    born_beyond_snow_line       BOOLEAN NULL,  -- v132 (GEN.458): formed beyond its star's snow line, NULL when the host has none to compare
    ozone_column_du             DOUBLE NULL,  -- v135 (GEN.413): the ozone column, Dobson units
    tau_haze                    DOUBLE NULL,  -- v138 (GEN.414, DB.68): haze optical depth at 550 nm, NULL for a row saved before v138 or a body with no air
    tau_dust                    DOUBLE NULL,  -- v138 (GEN.414, DB.68): dust optical depth at 550 nm
    tau_cloud                   DOUBLE NULL,  -- v138 (GEN.414, DB.68): in-cloud optical depth at 550 nm (grey)
    cloud_cover                 DOUBLE NULL,  -- v138 (GEN.414, DB.68): share of the sky under cloud, 0 to 1
    aerosol_draw                DOUBLE NULL,  -- v138 (GEN.414, DB.68): the number in [0, 1) that picks the optics inside the brackets
    c_k0_ppm                    DOUBLE,  -- v141 (GEN.459): potassium in the bulk silicate at formation, ppm by mass
    c_th0_ppm                   DOUBLE,  -- v141: thorium, the same
    c_u0_ppm                    DOUBLE,  -- v141: uranium, the same
    al26_ratio                  DOUBLE,  -- v141: 26Al/27Al at formation
    urey_ratio                  DOUBLE,  -- v141: the radiogenic share of the heat flowing out, today (an output of the thermal history since v146)
    bond_albedo                 DOUBLE NULL,  -- v142 (GEN.412): the Bond albedo drawn for the temperature
    greenhouse_factor           DOUBLE NULL,  -- v142: the greenhouse quantity G (T_s = T_e (1 + G)^(1/4)), 0 for no air
    albedo_basis                TINYINT UNSIGNED NULL,  -- v142: 0 recorded at generation, 1 exact inverse of a stored row, 2 seeded class draw
    metal_mass_fraction         DOUBLE,  -- v144 (DB.69, GEN.428): the iron-rich core's share of the whole body's mass, light elements included
    rock_mass_fraction          DOUBLE,  -- v144: the silicate (or silicon carbide and graphite) share
    ice_mass_fraction           DOUBLE,  -- v144: every ice other than water, as one share
    ice_co2_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is carbon dioxide ice
    ice_ch4_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is methane ice
    ice_nh3_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is ammonia ice
    ice_n2_mass_fraction        DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is nitrogen ice
    ice_so2_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is sulfur dioxide ice
    ice_co_mass_fraction        DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is carbon monoxide ice
    ice_hcn_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is hydrogen cyanide ice
    ice_other_mass_fraction     DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is every other ice (ethane, methanol, formaldehyde, hydrogen sulfide) ice
    envelope_mass_fraction      DOUBLE,  -- v144: the hydrogen and helium share
    rock_feo_fraction           DOUBLE,  -- v144: FeO, a mass fraction of the rock
    rock_al2o3_fraction         DOUBLE,  -- v144: Al2O3, a mass fraction of the rock
    rock_mg_si_ratio            DOUBLE,  -- v144: the rock's molar Mg/Si
    envelope_helium_fraction    DOUBLE,  -- v144: Y, a mass fraction of the envelope
    envelope_z_fraction         DOUBLE,  -- v144: heavy elements, a mass fraction of the envelope
    porosity                    DOUBLE,  -- v144: the void share of a small body's volume
    carbon_rock                 BOOLEAN,  -- v144: the rock is silicon carbide and graphite, not silicate
    composition_origin          VARCHAR(8) CHECK (composition_origin IN ('drawn', 'inverse')),  -- v144: drawn (composition first) or inverse (worked back from a mass and a radius)
    ground_type                   VARCHAR(16),  -- v159 (GEN.441): the ground type with the largest areal share (ocean, ice or a rock type)
    ground_grain                  VARCHAR(8),  -- v159: slab, crushed or powder
    ground_ocean_fraction         DOUBLE,  -- v159: the areal share of the surface that is ocean (the twelve shares add up to 1)
    ground_ice_fraction           DOUBLE,  -- v159: the areal share of the surface that is ice
    ground_ultramafic_fraction    DOUBLE,  -- v159: the areal share of the surface that is ultramafic
    ground_anorthositic_fraction  DOUBLE,  -- v159: the areal share of the surface that is anorthositic
    ground_basaltic_fraction      DOUBLE,  -- v159: the areal share of the surface that is basaltic
    ground_felsic_fraction        DOUBLE,  -- v159: the areal share of the surface that is felsic
    ground_clay_fraction          DOUBLE,  -- v159: the areal share of the surface that is clay
    ground_oxidised_fraction      DOUBLE,  -- v159: the areal share of the surface that is oxidised
    ground_metal_fraction         DOUBLE,  -- v159: the areal share of the surface that is metal
    ground_carbon_fraction        DOUBLE,  -- v159: the areal share of the surface that is carbon
    ground_evaporite_fraction     DOUBLE,  -- v159: the areal share of the surface that is evaporite
    ground_sulfur_fraction        DOUBLE,  -- v159: the areal share of the surface that is sulfur
    ground_intermediate_fraction  DOUBLE,  -- v190 (GEN.474): the areal share of the surface that is intermediate (andesitic) ground
    surface_liquid                VARCHAR(32),  -- v188 (GEN.1035): the liquid the surface holds (an id of physics/surface_liquids.py, NULL: none)
    surface_liquid_fraction       DOUBLE,  -- v188: the share of the surface that liquid covers
    surface_liquid_depth_km       DOUBLE,  -- v188: its mean depth over that share, km (NULL: not known)
    moon_origin                   VARCHAR(8),  -- v180 (DB.70): how a moon came to orbit its parent (NULL for a planet and for a moon saved before)
    moon_disk_lifetime_myr        DOUBLE,  -- v180: a giant planet's circumplanetary disk: its lifetime, Myr (NULL for a body with no disk)
    moon_disk_alpha_over_f        DOUBLE,  -- v180: the disk's alpha over f (the viscosity over the supply ratio of Canup and Ward)
    moon_disk_f_inf               DOUBLE,  -- v180: the asymptotic ice fraction of the disk's ramp
    moon_disk_ice_line_km         DOUBLE,  -- v180: the distance of the disk's ice line from the giant, km
    water_base_pressure_pa      DOUBLE NULL,  -- v151 (GEN.461): the pressure at the bottom of the water layer, Pa
    tidal_flux_w_m2             DOUBLE NULL,  -- v152 (GEN.700): the eccentricity-tide heat flow of an icy moon under ice, W/m2 (NULL for a planet)
    aquifer_depth_km            DOUBLE NULL,  -- v157 (GEN.654, DB.92): the depth to the top of the water-bearing layer underground, km (NULL: none)
    aquifer_thickness_km        DOUBLE NULL,  -- v156: the thickness of that layer, km
    mantle_eta0_pa_s            DOUBLE NULL,  -- v153 (GEN.699): the viscosity prefactor of the mantle, eta = eta0 exp(Ea / R T), Pa s
    mantle_activation_kj_mol    DOUBLE NULL,  -- v153: its viscosity activation energy Ea, kJ/mol
    internal_heat_flux_w_m2     DOUBLE NULL,  -- v153: the heat flowing out of the interior, radiogenic plus primordial, over the body's surface
    interior_kind               VARCHAR(16) CHECK (interior_kind IN ('gas_giant', 'ice_giant', 'brown_dwarf')),  -- v154 (DB.89, GEN.642): the kind of interior a giant was drawn with
    core_mass_earth             DOUBLE,  -- v154: the compact core's (an ice giant's rock core's) mass in Earth masses, 0 with none
    dilute_core_mass_earth      DOUBLE,  -- v154: the dilute core's mass in Earth masses, 0 with none
    metallization_pressure_gpa  DOUBLE,  -- v154: the drawn molecular-to-metallic pressure, GPa
    helium_depletion            DOUBLE,  -- v154: the molecular envelope's helium share against the natal share, 1 with no helium rain
    has_helium_shell            BOOLEAN,  -- v154: a helium-rich shell above the metallic envelope
    ring_kind                   VARCHAR(8) CHECK (ring_kind IN ('dusty', 'narrow', 'broad')),  -- v160 (GEN.732): the kind of the ring system, NULL with none
    ring_origin                 VARCHAR(16) CHECK (ring_origin IN ('moon_erosion', 'disrupted_moon', 'captured_body')),  -- v160: where its material came from
    ring_inner_km               DOUBLE,  -- v160: the inner edge of the ring system, km from the body's centre
    ring_outer_km               DOUBLE,  -- v160: its outer edge, km (inside the Roche limit of its own material and the innermost moon)
    ring_mass_kg                DOUBLE,  -- v160: its mass, kg
    ring_optical_depth          DOUBLE,  -- v160: its mean optical depth over the area it covers
    ring_ice_fraction           DOUBLE,  -- v160: its water-ice share by mass
    ring_age_yr                 DOUBLE,  -- v192 (GEN.1057): years since the event that made it (a fallen moon or a passing comet), NULL for a resonance ring
    atmosphere_colour           INT UNSIGNED,  -- v162 (DB.96): the colour of the body's air, sRGB as red*65536 + green*256 + blue, NULL with no air
    lid_regime                  VARCHAR(10) NULL,  -- v169 (GEN.721): mobile (plate tectonics) or stagnant (one rigid plate), drawn once, NULL for a gas giant
    day_share_equator           DOUBLE NULL,  -- v170 (GEN.767): share of the time the star is up at the equator over a year, 0 to 1, NULL for a world that turns once an orbit
    day_share_mean              DOUBLE NULL,  -- v170 (GEN.767): share of the time the star is up, averaged over the surface, 0 to 1
    parent_shadow_share         DOUBLE NULL,  -- v170 (GEN.767): a moon only, the share of its time in its planet's shadow, 0 to 1
    solar_day_hours             DOUBLE NULL,  -- v170 (GEN.767): hours from one noon to the next, NULL for a world that turns once an orbit
    daylight_hours              DOUBLE NULL,  -- v170 (GEN.767): hours of daylight in one solar day at the equator, NULL for a world that turns once an orbit
    polar_circle_deg            DOUBLE NULL,  -- v170 (GEN.767): latitude beyond which the star stays up or down for at least a day, degrees
    life_class                  TINYINT UNSIGNED NULL,  -- v175 (GEN.889): the number of the life class that lives on the body (physics/life_classes.py), NULL for none
    life_class_variant          CHAR(1) NULL,  -- v175: its pigment or habitat letter (1a, 1b, 1c, 3a ...), NULL for a class with none
    life_class_best             VARCHAR(2) NULL,  -- v175: the id of the best-supported class, NULL when no class is supported
    life_class_best_score       TINYINT UNSIGNED NULL,  -- v175: its score, 0 to 9
    life_animal_grade           TINYINT UNSIGNED NULL,  -- v175 (GEN.890): 0 no animals, 1 sessile, 2 small and mobile, 3 large and active
    life_complexity             DOUBLE NULL,  -- v175: the complexity index of its life class, 1 for an Earth-like biosphere
    tide_range_spring_m         DOUBLE NULL,  -- v191 (GEN.1034): open-ocean equilibrium spring tide range, metres, 0 under an ice cover, NULL without a sea
    tide_range_neap_m           DOUBLE NULL,  -- v191 (GEN.1034): the neap range, metres
    ocean_liquid                VARCHAR(40) NULL,  -- v191 (GEN.1034): the liquid of the sea the tide is of (water until GEN.1035), NULL without a sea
    UNIQUE KEY uq_planets_uid (uid),
    CONSTRAINT fk_planets_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_planets_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_planets_star_system_id (star_system_id),
    KEY idx_planets_next_update_due (next_update_due),
    KEY idx_planets_star_id (star_id),
    KEY idx_planets_name (name),
    FULLTEXT KEY ft_planets_name (name),
    KEY idx_planets_planet_class (planet_class),
    KEY idx_planets_body_type (body_type),
    KEY idx_planets_life_class (life_class),
    KEY idx_planets_radius_km (radius_km),
    CONSTRAINT chk_planets_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    KEY idx_planets_parent (parent_type, parent_id),
    CONSTRAINT chk_planets_dynamical_state CHECK (dynamical_state IN ('bound', 'unbound'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planet_reflection_spectrum (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id      BIGINT UNSIGNED NOT NULL,
    spectrum_type  VARCHAR(16) NOT NULL CHECK (spectrum_type IN ('visible', 'non_visible')),
    position       INT NOT NULL,
    value          VARCHAR(255) NOT NULL,
    CONSTRAINT fk_planet_reflection_spectrum_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    KEY idx_planet_reflection_spectrum_planet_id (planet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planet_interior_layers (
    id                      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id               BIGINT UNSIGNED NOT NULL,
    layer_index             SMALLINT UNSIGNED NOT NULL,
    kind                    VARCHAR(24) NOT NULL CHECK (kind IN ('molecular_envelope', 'metallic_envelope', 'helium_gradient', 'helium_shell', 'dilute_core', 'compact_core', 'ice_mantle', 'rock_core')),
    state                   VARCHAR(16) NOT NULL CHECK (state IN ('molecular_fluid', 'metallic_fluid', 'ionic_fluid', 'superionic', 'molten')),
    top_pressure_gpa        DOUBLE NOT NULL,
    bottom_pressure_gpa     DOUBLE NOT NULL,
    mass_earth              DOUBLE NOT NULL,
    top_radius_fraction     DOUBLE NOT NULL,
    bottom_radius_fraction  DOUBLE NOT NULL,
    hydrogen                DOUBLE NOT NULL,
    helium                  DOUBLE NOT NULL,
    iron                    DOUBLE NOT NULL,
    rock                    DOUBLE NOT NULL,
    water_liquid            DOUBLE NOT NULL,
    ice_x                   DOUBLE NOT NULL,
    nh3_ice                 DOUBLE NOT NULL,
    ch4_ice                 DOUBLE NOT NULL,
    UNIQUE KEY uq_planet_interior_layers_index (planet_id, layer_index),
    CONSTRAINT fk_planet_interior_layers_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planet_gases (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id  BIGINT UNSIGNED NOT NULL,
    gas         VARCHAR(16) NOT NULL,
    partial_pa  DOUBLE NOT NULL CHECK (partial_pa > 0),
    CONSTRAINT fk_planet_gases_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    UNIQUE KEY uq_planet_gases (planet_id, gas)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS planet_life_class_scores (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id   BIGINT UNSIGNED NOT NULL,
    life_class  VARCHAR(2) NOT NULL,
    score       TINYINT UNSIGNED NOT NULL CHECK (score BETWEEN 1 AND 9),
    CONSTRAINT fk_planet_life_class_scores_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    UNIQUE KEY uq_planet_life_class_scores (planet_id, life_class),
    KEY idx_planet_life_class_scores_class (life_class, score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moons (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    planet_id                 BIGINT UNSIGNED NULL,  -- v140 (DB.73): NULL for a moon of a free planet
    star_system_id            BIGINT UNSIGNED NULL,  -- v140 (DB.73): NULL for a moon of a free planet
    star_id                   BIGINT UNSIGNED,
    orbital_index             INT NOT NULL,   -- position in the parent planet's moons list
    body_type                 VARCHAR(4) NOT NULL CHECK (body_type IN ('t', 'g')),
    name                      VARCHAR(255) NOT NULL,
    planet_class              VARCHAR(16),
    distance_km               DOUBLE NOT NULL,   -- from the parent planet
    radius_km                 DOUBLE NOT NULL,
    mass_kg                   DOUBLE NOT NULL,
    volume_km3                DOUBLE NOT NULL,
    period_years              DOUBLE NOT NULL,
    zone                      VARCHAR(4) CHECK (zone IN ('h', 'e', 'c')),
    description               TEXT,
    gravity_g                 DOUBLE,
    surface_temperature_k     DOUBLE,
    density_g_cm3             DOUBLE,
    atmosphere                TEXT,
    atm_density               DOUBLE,
    atm_molar_density         DOUBLE,
    atmospheric_pressure_pa   DOUBLE,
    composition               TEXT,
    scale_height_km           DOUBLE,
    hill_radius_km            DOUBLE,
    min_orbit_distance_km     DOUBLE,
    habitable_zone_inner_km   DOUBLE NOT NULL,
    habitable_zone_outer_km   DOUBLE NOT NULL,
    flavor_text_count         INT NOT NULL DEFAULT 0,
    life_stage                VARCHAR(32),      -- v110 (DB.50): a MILESTONE_KEYS key, NULL before any milestone
    evolutionary_pace         VARCHAR(16),      -- v110: the pace life evolves at (fast, normal, slow), drawn once, set with any life chemistry (v143)
    life_milestone_age_gyr    DOUBLE,           -- v110: the age of that milestone, Gy
    life_system_age_gyr       DOUBLE,           -- v110: the age of the system the timeline was written at, Gy
    life_age_abiogenesis_gyr  DOUBLE,           -- v156 (DB.100): the age the pace reaches abiogenesis, Gy
    life_age_photosynthesis_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches photosynthesis, Gy
    life_age_complex_cells_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches complex cells, Gy
    life_age_multicellularity_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches multicellularity, Gy
    life_age_technological_civilization_gyr DOUBLE,           -- v156 (DB.100): the age the pace reaches technological civilization, Gy
    flavor_key                VARCHAR(32),      -- v110: which flavour line (replaces flavor_text)
    orbital_inclination_deg     DOUBLE NOT NULL,
    orbital_ascending_node_deg  DOUBLE NOT NULL,
    eccentricity                DOUBLE NOT NULL DEFAULT 0,   -- v159 (GEN.727): of the orbit the body was generated on (distance_km is its semi-major axis)
    position_x_km               DOUBLE NOT NULL,
    position_y_km               DOUBLE NOT NULL,
    position_z_km               DOUBLE NOT NULL,
    orbital_speed_kms           DOUBLE NOT NULL,
    velocity_x_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms              DOUBLE NOT NULL DEFAULT 0,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    min_update_interval_years   DOUBLE NOT NULL,  -- v12, see header comment
    rotation_period_hours       DOUBLE NOT NULL,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    mantle_redox                VARCHAR(16) CHECK (mantle_redox IN ('reduced', 'intermediate', 'oxidized')),
    mantle_delta_iw             DOUBLE,
    magnetic_moment_a_m2        DOUBLE,
    dipole_class                VARCHAR(16) CHECK (dipole_class IN ('none', 'weak', 'earth-like', 'strong', 'multipolar')),
    induced_moment_a_m2         DOUBLE,
    magnetopause_rp             DOUBLE,
    xuv_flux_earth              DOUBLE,
    xuv_exposure_index          DOUBLE,
    flare_irradiation_index     DOUBLE,
    water_mass_fraction         DOUBLE,
    hydrosphere                 VARCHAR(20) CHECK (hydrosphere IN ('dry', 'vapour', 'ice', 'ice-covered ocean', 'surface ocean', 'brine seep', 'hycean')),
    ocean_fraction              DOUBLE,
    land_fraction               DOUBLE,
    ocean_depth_km              DOUBLE,
    ice_shell_km                DOUBLE,
    hp_ice_km                   DOUBLE,
    ocean_class                 VARCHAR(16) CHECK (ocean_class IN ('ice-sealed', 'chloride brine', 'acid sulfate', 'soda', 'neutral')),
    ocean_ph                    DOUBLE,
    water_activity              DOUBLE,
    phosphorus                  VARCHAR(8) CHECK (phosphorus IN ('high', 'limited', 'starved')),
    surface_dose_msv_yr         DOUBLE,
    dose_gcr_msv_yr             DOUBLE,
    dose_sep_msv_yr             DOUBLE,
    dose_ground_msv_yr          DOUBLE,
    dose_belt_msv_yr            DOUBLE,  -- v187 (GEN.983): the dose a moon takes from its parent's trapped-particle belts, mSv/yr (0 for a planet)
    dose_helio_mult             DOUBLE,
    uv_surface_index            DOUBLE,
    ozone_loss_flag             BOOLEAN,
    phi4                        DOUBLE,
    phi4_pressure               DOUBLE,
    phi4_temperature            DOUBLE,
    phi4_air                    DOUBLE,
    phi4_water                  DOUBLE,
    phi4_suitability            DOUBLE,
    phi4_radiation              DOUBLE,
    tier_pressure               TINYINT,
    tier_temperature            TINYINT,
    tier_air                    TINYINT,
    tier_water                  TINYINT,
    tier_suitability            TINYINT,
    tier_radiation              TINYINT,
    life_microbial              TINYINT UNSIGNED NULL,  -- v150 (GEN.649): 0 none to 9 abundant, from the evolutionary path and the surface
    life_flora                  TINYINT UNSIGNED NULL,  -- v150
    life_fauna                  TINYINT UNSIGNED NULL,  -- v150
    life_sentient               TINYINT UNSIGNED NULL,  -- v150
    l_solv                      DOUBLE,
    l_chem                      DOUBLE,
    l_ener                      DOUBLE,
    l_rad                       DOUBLE,
    eq_body                     TINYINT,
    eq_body_kind                TINYINT,
    eq_body_rec                 TINYINT,
    eq_body_rec_kind            TINYINT,
    eq_rad_suit                 TINYINT,
    eq_rad_suit_rec             TINYINT,
    eq_mobility                 TINYINT,
    eq_dust                     TINYINT,
    eq_gas_filter               TINYINT,
    eq_co2_scrub                TINYINT,
    eq_supply                   TINYINT,
    eq_supply_rec               TINYINT,
    eq_shelter                  TINYINT,
    eq_shelter_rec              TINYINT,
    shelter_column_g_cm2        DOUBLE,
    outside_hours               DOUBLE,
    band1_mean_k                DOUBLE,  -- v196 (GEN.1108): the climate of the body in seven bands of latitude (`physics/latitude_bands.py`): `band1` is the north pole, `band7` the south pole (a world locked to its star: the day centre to the night centre)
    band1_swing_k               DOUBLE,
    band1_day_hours             DOUBLE,
    band1_night_hours           DOUBLE,
    band1_longest_day_days      DOUBLE,
    band1_longest_night_days    DOUBLE,
    band1_state                 VARCHAR(24),
    band2_mean_k                DOUBLE,
    band2_swing_k               DOUBLE,
    band2_day_hours             DOUBLE,
    band2_night_hours           DOUBLE,
    band2_longest_day_days      DOUBLE,
    band2_longest_night_days    DOUBLE,
    band2_state                 VARCHAR(24),
    band3_mean_k                DOUBLE,
    band3_swing_k               DOUBLE,
    band3_day_hours             DOUBLE,
    band3_night_hours           DOUBLE,
    band3_longest_day_days      DOUBLE,
    band3_longest_night_days    DOUBLE,
    band3_state                 VARCHAR(24),
    band4_mean_k                DOUBLE,
    band4_swing_k               DOUBLE,
    band4_day_hours             DOUBLE,
    band4_night_hours           DOUBLE,
    band4_longest_day_days      DOUBLE,
    band4_longest_night_days    DOUBLE,
    band4_state                 VARCHAR(24),
    band5_mean_k                DOUBLE,
    band5_swing_k               DOUBLE,
    band5_day_hours             DOUBLE,
    band5_night_hours           DOUBLE,
    band5_longest_day_days      DOUBLE,
    band5_longest_night_days    DOUBLE,
    band5_state                 VARCHAR(24),
    band6_mean_k                DOUBLE,
    band6_swing_k               DOUBLE,
    band6_day_hours             DOUBLE,
    band6_night_hours           DOUBLE,
    band6_longest_day_days      DOUBLE,
    band6_longest_night_days    DOUBLE,
    band6_state                 VARCHAR(24),
    band7_mean_k                DOUBLE,
    band7_swing_k               DOUBLE,
    band7_day_hours             DOUBLE,
    band7_night_hours           DOUBLE,
    band7_longest_day_days      DOUBLE,
    band7_longest_night_days    DOUBLE,
    band7_state                 VARCHAR(24),
    temp_mean_swing_k           DOUBLE,  -- v182 (GEN.848): the day and night swing of the whole surface, peak to peak, kelvin of difference
    outside_hours_day           DOUBLE,  -- v187 (GEN.768): the hours of one local day a person can be outside in the listed equipment
    outside_hours_limit         VARCHAR(16),  -- v187 (GEN.768): what sets them: daylight, dose, heat, cold, air, uv or vehicle
    day_night_state             VARCHAR(24),  -- v188 (GEN.1097): the state of its day and night: day and night, tidally locked, spin-orbit resonance, non-rotating, polar day and night or no solid surface
    night_hours                 DOUBLE,  -- v188 (GEN.1097): hours of night in one solar day at the equator, NULL for a world that turns once an orbit
    days_per_year               DOUBLE,  -- v188 (GEN.1097): solar days in one orbit round the star, NULL for a world that turns once an orbit
    roundness_ratio             DOUBLE,  -- v197 (GEN.1159): the mean radius over the round radius, 1 or more is round and less is not
    yield_strength_pa           DOUBLE,  -- v197 (GEN.1159): the whole-body strength of the material mix of the body, Pa, drawn from the range of each material (GEN.1178)
    binding_energy_j            DOUBLE,  -- v197 (GEN.1159): the energy that assembling the body releases, J
    energy_flux_w_m2            DOUBLE,
    flux_variation              DOUBLE,
    uid                   BINARY(12),
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'planet',  -- v102 (DB.55), v140 (DB.73): wider
    parent_id                   BIGINT UNSIGNED NULL,  -- v102 (DB.55)
    dynamical_state             VARCHAR(8) NOT NULL DEFAULT 'bound',  -- v102 (DB.55)
    born_beyond_snow_line       BOOLEAN NULL,  -- v132 (GEN.458): the parent planet's flag
    ozone_column_du             DOUBLE NULL,  -- v135 (GEN.413): the ozone column, Dobson units
    tau_haze                    DOUBLE NULL,  -- v138 (GEN.414, DB.68): haze optical depth at 550 nm, NULL for a row saved before v138 or a body with no air
    tau_dust                    DOUBLE NULL,  -- v138 (GEN.414, DB.68): dust optical depth at 550 nm
    tau_cloud                   DOUBLE NULL,  -- v138 (GEN.414, DB.68): in-cloud optical depth at 550 nm (grey)
    cloud_cover                 DOUBLE NULL,  -- v138 (GEN.414, DB.68): share of the sky under cloud, 0 to 1
    aerosol_draw                DOUBLE NULL,  -- v138 (GEN.414, DB.68): the number in [0, 1) that picks the optics inside the brackets
    rogue_planet_id             BIGINT UNSIGNED NULL,  -- v140 (DB.73): the rogue planet a moon of a free planet orbits
    c_k0_ppm                    DOUBLE,  -- v141 (GEN.459): potassium in the bulk silicate at formation, ppm by mass
    c_th0_ppm                   DOUBLE,  -- v141: thorium, the same
    c_u0_ppm                    DOUBLE,  -- v141: uranium, the same
    al26_ratio                  DOUBLE,  -- v141: 26Al/27Al at formation
    urey_ratio                  DOUBLE,  -- v141: the radiogenic share of the heat flowing out, today (an output of the thermal history since v146)
    bond_albedo                 DOUBLE NULL,  -- v142 (GEN.412): the Bond albedo drawn for the temperature
    greenhouse_factor           DOUBLE NULL,  -- v142: the greenhouse quantity G (T_s = T_e (1 + G)^(1/4)), 0 for no air
    albedo_basis                TINYINT UNSIGNED NULL,  -- v142: 0 recorded at generation, 1 exact inverse of a stored row, 2 seeded class draw
    metal_mass_fraction         DOUBLE,  -- v144 (DB.69, GEN.428): the iron-rich core's share of the whole body's mass, light elements included
    rock_mass_fraction          DOUBLE,  -- v144: the silicate (or silicon carbide and graphite) share
    ice_mass_fraction           DOUBLE,  -- v144: every ice other than water, as one share
    ice_co2_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is carbon dioxide ice
    ice_ch4_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is methane ice
    ice_nh3_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is ammonia ice
    ice_n2_mass_fraction        DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is nitrogen ice
    ice_so2_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is sulfur dioxide ice
    ice_co_mass_fraction        DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is carbon monoxide ice
    ice_hcn_mass_fraction       DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is hydrogen cyanide ice
    ice_other_mass_fraction     DOUBLE,  -- v183 (GEN.834): the share of the whole body's mass that is every other ice (ethane, methanol, formaldehyde, hydrogen sulfide) ice
    envelope_mass_fraction      DOUBLE,  -- v144: the hydrogen and helium share
    rock_feo_fraction           DOUBLE,  -- v144: FeO, a mass fraction of the rock
    rock_al2o3_fraction         DOUBLE,  -- v144: Al2O3, a mass fraction of the rock
    rock_mg_si_ratio            DOUBLE,  -- v144: the rock's molar Mg/Si
    envelope_helium_fraction    DOUBLE,  -- v144: Y, a mass fraction of the envelope
    envelope_z_fraction         DOUBLE,  -- v144: heavy elements, a mass fraction of the envelope
    porosity                    DOUBLE,  -- v144: the void share of a small body's volume
    carbon_rock                 BOOLEAN,  -- v144: the rock is silicon carbide and graphite, not silicate
    composition_origin          VARCHAR(8) CHECK (composition_origin IN ('drawn', 'inverse')),  -- v144: drawn (composition first) or inverse (worked back from a mass and a radius)
    ground_type                   VARCHAR(16),  -- v159 (GEN.441): the ground type with the largest areal share (ocean, ice or a rock type)
    ground_grain                  VARCHAR(8),  -- v159: slab, crushed or powder
    ground_ocean_fraction         DOUBLE,  -- v159: the areal share of the surface that is ocean (the twelve shares add up to 1)
    ground_ice_fraction           DOUBLE,  -- v159: the areal share of the surface that is ice
    ground_ultramafic_fraction    DOUBLE,  -- v159: the areal share of the surface that is ultramafic
    ground_anorthositic_fraction  DOUBLE,  -- v159: the areal share of the surface that is anorthositic
    ground_basaltic_fraction      DOUBLE,  -- v159: the areal share of the surface that is basaltic
    ground_felsic_fraction        DOUBLE,  -- v159: the areal share of the surface that is felsic
    ground_clay_fraction          DOUBLE,  -- v159: the areal share of the surface that is clay
    ground_oxidised_fraction      DOUBLE,  -- v159: the areal share of the surface that is oxidised
    ground_metal_fraction         DOUBLE,  -- v159: the areal share of the surface that is metal
    ground_carbon_fraction        DOUBLE,  -- v159: the areal share of the surface that is carbon
    ground_evaporite_fraction     DOUBLE,  -- v159: the areal share of the surface that is evaporite
    ground_sulfur_fraction        DOUBLE,  -- v159: the areal share of the surface that is sulfur
    ground_intermediate_fraction  DOUBLE,  -- v190 (GEN.474): the areal share of the surface that is intermediate (andesitic) ground
    surface_liquid                VARCHAR(32),  -- v188 (GEN.1035): the liquid the surface holds (an id of physics/surface_liquids.py, NULL: none)
    surface_liquid_fraction       DOUBLE,  -- v188: the share of the surface that liquid covers
    surface_liquid_depth_km       DOUBLE,  -- v188: its mean depth over that share, km (NULL: not known)
    moon_origin                   VARCHAR(8),  -- v180 (DB.70): how a moon came to orbit its parent (NULL for a planet and for a moon saved before)
    moon_disk_lifetime_myr        DOUBLE,  -- v180: a giant planet's circumplanetary disk: its lifetime, Myr (NULL for a body with no disk)
    moon_disk_alpha_over_f        DOUBLE,  -- v180: the disk's alpha over f (the viscosity over the supply ratio of Canup and Ward)
    moon_disk_f_inf               DOUBLE,  -- v180: the asymptotic ice fraction of the disk's ramp
    moon_disk_ice_line_km         DOUBLE,  -- v180: the distance of the disk's ice line from the giant, km
    water_base_pressure_pa      DOUBLE NULL,  -- v147 (GEN.461): the pressure at the bottom of the water layer, Pa
    tidal_flux_w_m2             DOUBLE NULL,  -- v152 (GEN.700): the eccentricity-tide heat flow of an icy moon under ice, W/m2
    aquifer_depth_km            DOUBLE NULL,  -- v157 (GEN.654, DB.92): the depth to the top of the water-bearing layer underground, km (NULL: none)
    aquifer_thickness_km        DOUBLE NULL,  -- v156: the thickness of that layer, km
    mantle_eta0_pa_s            DOUBLE NULL,  -- v153 (GEN.699): the viscosity prefactor of the mantle, eta = eta0 exp(Ea / R T), Pa s
    mantle_activation_kj_mol    DOUBLE NULL,  -- v153: its viscosity activation energy Ea, kJ/mol
    internal_heat_flux_w_m2     DOUBLE NULL,  -- v153: the heat flowing out of the interior, radiogenic plus primordial, over the body's surface
    interior_kind               VARCHAR(16) CHECK (interior_kind IN ('gas_giant', 'ice_giant', 'brown_dwarf')),  -- v154 (DB.89, GEN.642): the kind of interior a giant was drawn with
    core_mass_earth             DOUBLE,  -- v154: the compact core's (an ice giant's rock core's) mass in Earth masses, 0 with none
    dilute_core_mass_earth      DOUBLE,  -- v154: the dilute core's mass in Earth masses, 0 with none
    metallization_pressure_gpa  DOUBLE,  -- v154: the drawn molecular-to-metallic pressure, GPa
    helium_depletion            DOUBLE,  -- v154: the molecular envelope's helium share against the natal share, 1 with no helium rain
    has_helium_shell            BOOLEAN,  -- v154: a helium-rich shell above the metallic envelope
    ring_kind                   VARCHAR(8) CHECK (ring_kind IN ('dusty', 'narrow', 'broad')),  -- v160 (GEN.732): the kind of the ring system, NULL with none
    ring_origin                 VARCHAR(16) CHECK (ring_origin IN ('moon_erosion', 'disrupted_moon', 'captured_body')),  -- v160: where its material came from
    ring_inner_km               DOUBLE,  -- v160: the inner edge of the ring system, km from the body's centre
    ring_outer_km               DOUBLE,  -- v160: its outer edge, km (inside the Roche limit of its own material and the innermost moon)
    ring_mass_kg                DOUBLE,  -- v160: its mass, kg
    ring_optical_depth          DOUBLE,  -- v160: its mean optical depth over the area it covers
    ring_ice_fraction           DOUBLE,  -- v160: its water-ice share by mass
    ring_age_yr                 DOUBLE,  -- v192 (GEN.1057): years since the event that made it (a fallen moon or a passing comet), NULL for a resonance ring
    atmosphere_colour           INT UNSIGNED,  -- v161 (DB.96): the colour of the body's air, sRGB as red*65536 + green*256 + blue, NULL with no air
    lid_regime                  VARCHAR(10) NULL,  -- v169 (GEN.721): mobile (plate tectonics) or stagnant (one rigid plate), drawn once, NULL for a gas giant
    day_share_equator           DOUBLE NULL,  -- v170 (GEN.767): share of the time the star is up at the equator over a year, 0 to 1, NULL for a world that turns once an orbit
    day_share_mean              DOUBLE NULL,  -- v170 (GEN.767): share of the time the star is up, averaged over the surface, 0 to 1
    parent_shadow_share         DOUBLE NULL,  -- v170 (GEN.767): a moon only, the share of its time in its planet's shadow, 0 to 1
    solar_day_hours             DOUBLE NULL,  -- v170 (GEN.767): hours from one noon to the next, NULL for a world that turns once an orbit
    daylight_hours              DOUBLE NULL,  -- v170 (GEN.767): hours of daylight in one solar day at the equator, NULL for a world that turns once an orbit
    polar_circle_deg            DOUBLE NULL,  -- v170 (GEN.767): latitude beyond which the star stays up or down for at least a day, degrees
    life_class                  TINYINT UNSIGNED NULL,  -- v175 (GEN.889): the number of the life class that lives on the body (physics/life_classes.py), NULL for none
    life_class_variant          CHAR(1) NULL,  -- v175: its pigment or habitat letter (1a, 1b, 1c, 3a ...), NULL for a class with none
    life_class_best             VARCHAR(2) NULL,  -- v175: the id of the best-supported class, NULL when no class is supported
    life_class_best_score       TINYINT UNSIGNED NULL,  -- v175: its score, 0 to 9
    life_animal_grade           TINYINT UNSIGNED NULL,  -- v175 (GEN.890): 0 no animals, 1 sessile, 2 small and mobile, 3 large and active
    life_complexity             DOUBLE NULL,  -- v175: the complexity index of its life class, 1 for an Earth-like biosphere
    tide_range_spring_m         DOUBLE NULL,  -- v191 (GEN.1034): open-ocean equilibrium spring tide range, metres, 0 under an ice cover, NULL without a sea
    tide_range_neap_m           DOUBLE NULL,  -- v191 (GEN.1034): the neap range, metres
    ocean_liquid                VARCHAR(40) NULL,  -- v191 (GEN.1034): the liquid of the sea the tide is of (water until GEN.1035), NULL without a sea
    UNIQUE KEY uq_moons_uid (uid),
    CONSTRAINT fk_moons_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    CONSTRAINT fk_moons_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_moons_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    CONSTRAINT fk_moons_rogue_planet
        FOREIGN KEY (rogue_planet_id) REFERENCES rogue_planets(id) ON DELETE CASCADE,
    KEY idx_moons_rogue_planet_id (rogue_planet_id),
    KEY idx_moons_planet_id (planet_id),
    KEY idx_moons_next_update_due (next_update_due),
    KEY idx_moons_star_system_id (star_system_id),
    KEY idx_moons_star_id (star_id),
    KEY idx_moons_name (name),
    FULLTEXT KEY ft_moons_name (name),
    KEY idx_moons_planet_class (planet_class),
    KEY idx_moons_body_type (body_type),
    KEY idx_moons_life_class (life_class),
    KEY idx_moons_radius_km (radius_km),
    CONSTRAINT chk_moons_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    KEY idx_moons_parent (parent_type, parent_id),
    CONSTRAINT chk_moons_dynamical_state CHECK (dynamical_state IN ('bound', 'unbound'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moon_reflection_spectrum (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    moon_id        BIGINT UNSIGNED NOT NULL,
    spectrum_type  VARCHAR(16) NOT NULL CHECK (spectrum_type IN ('visible', 'non_visible')),
    position       INT NOT NULL,
    value          VARCHAR(255) NOT NULL,
    CONSTRAINT fk_moon_reflection_spectrum_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    KEY idx_moon_reflection_spectrum_moon_id (moon_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moon_interior_layers (
    id                      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    moon_id                 BIGINT UNSIGNED NOT NULL,
    layer_index             SMALLINT UNSIGNED NOT NULL,
    kind                    VARCHAR(24) NOT NULL CHECK (kind IN ('molecular_envelope', 'metallic_envelope', 'helium_gradient', 'helium_shell', 'dilute_core', 'compact_core', 'ice_mantle', 'rock_core')),
    state                   VARCHAR(16) NOT NULL CHECK (state IN ('molecular_fluid', 'metallic_fluid', 'ionic_fluid', 'superionic', 'molten')),
    top_pressure_gpa        DOUBLE NOT NULL,
    bottom_pressure_gpa     DOUBLE NOT NULL,
    mass_earth              DOUBLE NOT NULL,
    top_radius_fraction     DOUBLE NOT NULL,
    bottom_radius_fraction  DOUBLE NOT NULL,
    hydrogen                DOUBLE NOT NULL,
    helium                  DOUBLE NOT NULL,
    iron                    DOUBLE NOT NULL,
    rock                    DOUBLE NOT NULL,
    water_liquid            DOUBLE NOT NULL,
    ice_x                   DOUBLE NOT NULL,
    nh3_ice                 DOUBLE NOT NULL,
    ch4_ice                 DOUBLE NOT NULL,
    UNIQUE KEY uq_moon_interior_layers_index (moon_id, layer_index),
    CONSTRAINT fk_moon_interior_layers_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moon_gases (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    moon_id  BIGINT UNSIGNED NOT NULL,
    gas         VARCHAR(16) NOT NULL,
    partial_pa  DOUBLE NOT NULL CHECK (partial_pa > 0),
    CONSTRAINT fk_moon_gases_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    UNIQUE KEY uq_moon_gases (moon_id, gas)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS moon_life_class_scores (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    moon_id   BIGINT UNSIGNED NOT NULL,
    life_class  VARCHAR(2) NOT NULL,
    score       TINYINT UNSIGNED NOT NULL CHECK (score BETWEEN 1 AND 9),
    CONSTRAINT fk_moon_life_class_scores_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    UNIQUE KEY uq_moon_life_class_scores (moon_id, life_class),
    KEY idx_moon_life_class_scores_class (life_class, score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_belts (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id       BIGINT UNSIGNED NOT NULL,
    star_id              BIGINT UNSIGNED,
    orbital_index        INT NOT NULL,
    distance_km          DOUBLE NOT NULL,
    lower_limit_km       DOUBLE NOT NULL,   -- distance, low (asteroidData.py's "distance_text" range)
    upper_limit_km       DOUBLE NOT NULL,   -- distance, high
    density              VARCHAR(16) NOT NULL CHECK (density IN ('dense', 'sparse', 'typical')),
    composition_summary  TEXT NOT NULL,
    uid                   BINARY(12),
    position_x_km               DOUBLE NULL,  -- v102 (DB.55): system-frame offset from the system centre, km
    position_y_km               DOUBLE NULL,  -- v102 (DB.55): system-frame offset from the system centre, km
    position_z_km               DOUBLE NULL,  -- v102 (DB.55): system-frame offset from the system centre, km
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    density_g_cm3               DOUBLE,  -- v197 (GEN.1159): the mean bulk density of the members, g/cm3
    ice_mass_fraction           DOUBLE,  -- v197 (GEN.1159): the mean share of the mass of a member that is ice of any kind
    epoch_unix                  DOUBLE NULL,  -- v102 (DB.55): when the position and velocity hold
    next_update_due             DOUBLE NULL,  -- v102 (DB.55): when the object next moves
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'system',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    chondrite_group             VARCHAR(4) NULL,  -- v190 (GEN.475): the nearest chondrite group of the belt's mean composition (CI, CM, H, L ...), `none` far from every group, NULL before v190
    UNIQUE KEY uq_asteroid_belts_uid (uid),
    KEY idx_asteroid_belts_parent (parent_type, parent_id),
    CONSTRAINT chk_asteroid_belts_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    CONSTRAINT fk_asteroid_belts_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_asteroid_belts_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_asteroid_belts_star_system_id (star_system_id),
    KEY idx_asteroid_belts_star_id (star_id),
    KEY idx_asteroid_belts_density (density)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_belt_composition (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    belt_id        BIGINT UNSIGNED NOT NULL,
    position       INT NOT NULL,
    component      VARCHAR(64) NOT NULL,
    concentration  VARCHAR(16) NOT NULL CHECK (concentration IN ('high', 'moderate', 'small', 'trace')),
    CONSTRAINT fk_asteroid_belt_composition_belt
        FOREIGN KEY (belt_id) REFERENCES asteroid_belts(id) ON DELETE CASCADE,
    KEY idx_asteroid_belt_composition_belt_id (belt_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS comets (
    id                          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_system_id              BIGINT UNSIGNED NOT NULL,
    star_id                     BIGINT UNSIGNED,
    name                        VARCHAR(255) NOT NULL,
    orbit_type                  VARCHAR(16) NOT NULL CHECK (orbit_type IN ('elliptical', 'parabolic')),
    period_class                VARCHAR(16) CHECK (period_class IN ('jupiter_family', 'halley_type', 'long_period')),
    nucleus_diameter_km         DOUBLE NOT NULL,
    composition_summary         TEXT NOT NULL,
    perihelion_distance_km      DOUBLE NOT NULL,
    eccentricity                DOUBLE NOT NULL,
    inclination_deg             DOUBLE NOT NULL,
    arg_periapsis_deg           DOUBLE NOT NULL,
    ascending_node_deg          DOUBLE NOT NULL,
    orbital_period_years        DOUBLE,
    mean_anomaly_deg            DOUBLE,
    parabolic_mean_anomaly      DOUBLE,
    min_update_interval_years   DOUBLE,
    primary_mass_solar          DOUBLE NOT NULL,
    is_active                   TINYINT(1) NOT NULL CHECK (is_active IN (0, 1)),
    distance_km                 DOUBLE NOT NULL,
    position_x_km               DOUBLE NOT NULL,
    position_y_km               DOUBLE NOT NULL,
    position_z_km               DOUBLE NOT NULL,
    orbital_speed_kms           DOUBLE NOT NULL,
    velocity_x_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms              DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms              DOUBLE NOT NULL DEFAULT 0,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    uid                   BINARY(12),
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    density_g_cm3               DOUBLE,  -- v197 (GEN.1159): the bulk density of the nucleus, g/cm3
    ice_mass_fraction           DOUBLE,  -- v197 (GEN.1159): the share of the nucleus mass that is ice of any kind
    roundness_ratio             DOUBLE,  -- v197 (GEN.1159): the mean radius over the round radius, 1 or more is round and less is not
    yield_strength_pa           DOUBLE,  -- v197 (GEN.1159): the strength of the material mix of the nucleus, Pa, drawn from the range of each material (GEN.1178)
    binding_energy_j            DOUBLE,  -- v197 (GEN.1159): the energy that assembling the nucleus releases, J
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'system',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    UNIQUE KEY uq_comets_uid (uid),
    KEY idx_comets_parent (parent_type, parent_id),
    CONSTRAINT chk_comets_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    CONSTRAINT fk_comets_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_comets_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE SET NULL,
    KEY idx_comets_star_system_id (star_system_id),
    KEY idx_comets_next_update_due (next_update_due),
    KEY idx_comets_star_id (star_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS comet_composition (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    comet_id    BIGINT UNSIGNED NOT NULL,
    position    INT NOT NULL,
    component   VARCHAR(64) NOT NULL,
    CONSTRAINT fk_comet_composition_comet
        FOREIGN KEY (comet_id) REFERENCES comets(id) ON DELETE CASCADE,
    KEY idx_comet_composition_comet_id (comet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS black_holes (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_id                   BIGINT UNSIGNED,
    sector_id                 BIGINT UNSIGNED,
    name                      VARCHAR(255) NOT NULL,
    mass_class                VARCHAR(16) NOT NULL DEFAULT 'stellar',
    mass_solar                DOUBLE NOT NULL,
    event_horizon_radius_km   DOUBLE NOT NULL,
    spin                      DOUBLE NOT NULL,
    has_accretion_disk        TINYINT(1) NOT NULL CHECK (has_accretion_disk IN (0, 1)),
    temperature_k             DOUBLE NOT NULL,
    luminosity_w              DOUBLE NOT NULL,
    age_gy                    DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE,
    galactic_orbital_phase_deg           DOUBLE,
    galactic_min_update_interval_years   DOUBLE,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    KEY idx_black_holes_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'free',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    UNIQUE KEY uq_black_holes_uid (uid),
    KEY idx_black_holes_parent (parent_type, parent_id),
    CONSTRAINT chk_black_holes_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    KEY idx_black_holes_name (name),  -- v40: name uniqueness lookups
    KEY idx_black_holes_placed_name (star_id, ((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_black_holes_descriptor_name (star_id, ((CASE WHEN has_accretion_disk THEN 'accreting' ELSE 'quiescent' END) COLLATE utf8mb4_unicode_ci), name),
    KEY idx_black_holes_next_update_due (next_update_due),
    CONSTRAINT chk_black_holes_mass_class CHECK (mass_class IN ('stellar', 'intermediate', 'supermassive')),
    CONSTRAINT chk_black_holes_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_black_holes_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE CASCADE,
    CONSTRAINT fk_black_holes_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_black_holes_star_id (star_id),
    KEY idx_black_holes_sector_id (sector_id),
    KEY idx_black_holes_galactic_radius_pc (galactic_radius_pc),
    KEY idx_black_holes_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_black_holes_modified_at (modified_at),
    CONSTRAINT fk_black_holes_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_black_holes_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS neutron_stars (
    id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    star_id                   BIGINT UNSIGNED,
    sector_id                 BIGINT UNSIGNED,
    name                      VARCHAR(255) NOT NULL,
    mass_solar                DOUBLE NOT NULL,
    radius_km                 DOUBLE NOT NULL,
    spin_period_ms            DOUBLE NOT NULL,
    magnetic_field_gauss      DOUBLE NOT NULL,
    pulsar_type               VARCHAR(16) NOT NULL CHECK (pulsar_type IN ('young', 'millisecond', 'magnetar', 'non-pulsing')),
    surface_temperature_k     DOUBLE NOT NULL,
    luminosity_w              DOUBLE NOT NULL,
    age_gy                    DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE,
    galactic_orbital_phase_deg           DOUBLE,
    galactic_min_update_interval_years   DOUBLE,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    KEY idx_neutron_stars_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'free',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    UNIQUE KEY uq_neutron_stars_uid (uid),
    KEY idx_neutron_stars_parent (parent_type, parent_id),
    CONSTRAINT chk_neutron_stars_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    KEY idx_neutron_stars_name (name),  -- v40: name uniqueness lookups
    KEY idx_neutron_stars_placed_name (star_id, ((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_neutron_stars_descriptor_name (star_id, pulsar_type, name),
    KEY idx_neutron_stars_next_update_due (next_update_due),
    CONSTRAINT chk_neutron_stars_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_neutron_stars_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE CASCADE,
    CONSTRAINT fk_neutron_stars_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_neutron_stars_star_id (star_id),
    KEY idx_neutron_stars_sector_id (sector_id),
    KEY idx_neutron_stars_galactic_radius_pc (galactic_radius_pc),
    KEY idx_neutron_stars_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_neutron_stars_modified_at (modified_at),
    CONSTRAINT fk_neutron_stars_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_neutron_stars_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebulae (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id         BIGINT UNSIGNED,
    name              VARCHAR(255) NOT NULL,
    nebula_class      CHAR(1) NOT NULL,
    nebula_type       VARCHAR(16) NOT NULL,
    radius_ly         DOUBLE NOT NULL,
    composition       TEXT NOT NULL,
    formation_cause   TEXT NOT NULL,
    dominant_species  VARCHAR(255) NOT NULL,
    density_cm3       DOUBLE NOT NULL,
    temperature_k     DOUBLE NOT NULL,
    extinction_av     DOUBLE NOT NULL,
    age_myr           DOUBLE,
    q_total           DOUBLE,
    hosts             VARCHAR(512),
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    KEY idx_nebulae_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    shape_axis_x          DOUBLE,
    shape_axis_y          DOUBLE,
    shape_axis_z          DOUBLE,
    shape_angle_x         DOUBLE,
    shape_angle_y         DOUBLE,
    shape_angle_z         DOUBLE,
    shape_warp_amplitude  DOUBLE,
    shape_warp_frequency  DOUBLE,
    shape_warp_octaves    INT,
    shape_noise_seed      BIGINT UNSIGNED,
    shape_iso             DOUBLE,
    shape_scale           DOUBLE,
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_nebulae_uid (uid),
    KEY idx_nebulae_name (name),  -- v40: name uniqueness lookups
    KEY idx_nebulae_placed_name (((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_nebulae_descriptor_name (nebula_type, name),
    KEY idx_nebulae_radius_name (radius_ly, name),
    KEY idx_nebulae_next_update_due (next_update_due),
    CONSTRAINT chk_nebulae_type CHECK (nebula_type IN ('diffuse', 'emission', 'reflection', 'planetary', 'dark')),
    CONSTRAINT chk_nebulae_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_nebulae_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_nebulae_sector_id (sector_id),
    KEY idx_nebulae_galactic_radius_pc (galactic_radius_pc),
    KEY idx_nebulae_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_nebulae_modified_at (modified_at),
    CONSTRAINT fk_nebulae_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_nebulae_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebula_shape_balls (
    nebula_id   BIGINT UNSIGNED NOT NULL,
    ball_index  INT NOT NULL,
    center_x    DOUBLE NOT NULL,
    center_y    DOUBLE NOT NULL,
    center_z    DOUBLE NOT NULL,
    radius      DOUBLE NOT NULL,
    PRIMARY KEY (nebula_id, ball_index),
    CONSTRAINT fk_nebula_shape_balls_nebula
        FOREIGN KEY (nebula_id) REFERENCES nebulae(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS supernova_remnants (
    id                                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id                         BIGINT UNSIGNED,
    name                              VARCHAR(255) NOT NULL,
    remnant_class                     CHAR(1) NOT NULL,
    morphology                        VARCHAR(16) NOT NULL CHECK (morphology IN ('shell', 'plerion', 'composite')),
    age_years                         DOUBLE NOT NULL,
    radius_ly                         DOUBLE NOT NULL,
    progenitor_type                   VARCHAR(16) NOT NULL CHECK (progenitor_type IN ('Type Ia', 'core-collapse')),
    compact_remnant_kind              VARCHAR(16) CHECK (compact_remnant_kind IN ('black_hole', 'neutron_star')),
    compact_remnant_black_hole_id     BIGINT UNSIGNED,
    compact_remnant_neutron_star_id   BIGINT UNSIGNED,
    dominant_species                  VARCHAR(255) NOT NULL,
    density_cm3                       DOUBLE NOT NULL,
    temperature_k                     DOUBLE NOT NULL,
    extinction_av                     DOUBLE NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    KEY idx_supernova_remnants_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_supernova_remnants_uid (uid),
    KEY idx_supernova_remnants_name (name),  -- v40: name uniqueness lookups
    KEY idx_supernova_remnants_placed_name (((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_supernova_remnants_descriptor_name (morphology, name),
    KEY idx_supernova_remnants_radius_name (radius_ly, name),
    KEY idx_supernova_remnants_next_update_due (next_update_due),
    CONSTRAINT chk_supernova_remnants_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_supernova_remnants_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    CONSTRAINT fk_supernova_remnants_black_hole
        FOREIGN KEY (compact_remnant_black_hole_id) REFERENCES black_holes(id) ON DELETE SET NULL,
    CONSTRAINT fk_supernova_remnants_neutron_star
        FOREIGN KEY (compact_remnant_neutron_star_id) REFERENCES neutron_stars(id) ON DELETE SET NULL,
    KEY idx_supernova_remnants_sector_id (sector_id),
    KEY idx_supernova_remnants_galactic_radius_pc (galactic_radius_pc),
    KEY idx_supernova_remnants_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_supernova_remnants_modified_at (modified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS quasars (
    id                              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id                       BIGINT UNSIGNED,
    name                            VARCHAR(255) NOT NULL,
    black_hole_mass_solar           DOUBLE NOT NULL,
    event_horizon_radius_km         DOUBLE NOT NULL,
    eddington_ratio                 DOUBLE NOT NULL,
    luminosity_w                    DOUBLE NOT NULL,
    accretion_rate_solar_per_year   DOUBLE NOT NULL,
    broad_line_region_light_days    DOUBLE NOT NULL,
    is_radio_loud                   TINYINT(1) NOT NULL CHECK (is_radio_loud IN (0, 1)),
    jet_length_ly                   DOUBLE,
    active_age_years                DOUBLE NOT NULL,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    epoch_unix                  DOUBLE NULL,  -- v102 (DB.55): when the position and velocity hold
    next_update_due             DOUBLE NULL,  -- v102 (DB.55): when the object next moves
    KEY idx_quasars_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    UNIQUE KEY uq_quasars_uid (uid),
    KEY idx_quasars_name (name),  -- v40: name uniqueness lookups
    KEY idx_quasars_placed_name (((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_quasars_descriptor_name (((CASE WHEN is_radio_loud THEN 'radio-loud' ELSE 'radio-quiet' END) COLLATE utf8mb4_unicode_ci), name),
    CONSTRAINT chk_quasars_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_quasars_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    KEY idx_quasars_sector_id (sector_id),
    KEY idx_quasars_galactic_radius_pc (galactic_radius_pc),
    KEY idx_quasars_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_quasars_modified_at (modified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS rogue_planets (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id           BIGINT UNSIGNED,
    name                VARCHAR(255) NOT NULL,
    planet_type         VARCHAR(4) NOT NULL CHECK (planet_type IN ('t', 'g')),
    planet_class        VARCHAR(4),
    mass_bin            VARCHAR(16) NOT NULL DEFAULT 'terrestrial',
    mass_kg             DOUBLE NOT NULL,
    radius_km           DOUBLE NOT NULL,
    composition         TEXT NOT NULL,
    has_internal_heat   TINYINT(1) NOT NULL CHECK (has_internal_heat IN (0, 1)),
    has_moons           TINYINT(1) NOT NULL CHECK (has_moons IN (0, 1)),
    age_gy                   DOUBLE,
    internal_heat_flux_w_m2  DOUBLE,
    effective_temperature_k  DOUBLE,
    surface_regime           VARCHAR(24),
    surface_temperature_k    DOUBLE,
    surface_pressure_pa      DOUBLE,
    ice_shell_thickness_km   DOUBLE,
    ocean_depth_km           DOUBLE,
    has_liquid_water         TINYINT(1),
    hp_ice_km                DOUBLE,  -- v74 (GEN.88)
    ring_kind                VARCHAR(8) CHECK (ring_kind IN ('dusty', 'narrow', 'broad')),
    ring_origin              VARCHAR(16) CHECK (ring_origin IN ('moon_erosion', 'disrupted_moon', 'captured_body')),
    ring_inner_km            DOUBLE,
    ring_outer_km            DOUBLE,
    ring_mass_kg             DOUBLE,
    ring_optical_depth       DOUBLE,
    ring_ice_fraction        DOUBLE,
    ring_age_yr              DOUBLE,  -- v192 (GEN.1057): as on `planets`
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    KEY idx_rogue_planets_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'free',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    phi4                        DOUBLE NULL,  -- v158 (GEN.701): the habitability score of the surface a visitor would find (rogue_habitability.py)
    phi4_pressure               DOUBLE NULL,  -- v153
    phi4_temperature            DOUBLE NULL,  -- v153
    phi4_air                    DOUBLE NULL,  -- v153
    phi4_water                  DOUBLE NULL,  -- v153
    phi4_radiation              DOUBLE NULL,  -- v153
    phi4_suitability            DOUBLE NULL,  -- v153
    tier_pressure               TINYINT NULL,  -- v153
    tier_temperature            TINYINT NULL,  -- v153
    tier_air                    TINYINT NULL,  -- v153
    tier_water                  TINYINT NULL,  -- v153
    tier_radiation              TINYINT NULL,  -- v153
    tier_suitability            TINYINT NULL,  -- v153
    life_microbial              TINYINT UNSIGNED NULL,  -- v153
    life_flora                  TINYINT UNSIGNED NULL,  -- v153
    life_fauna                  TINYINT UNSIGNED NULL,  -- v153
    life_sentient               TINYINT UNSIGNED NULL,  -- v153
    l_solv                      DOUBLE NULL,  -- v153
    l_chem                      DOUBLE NULL,  -- v153
    l_ener                      DOUBLE NULL,  -- v153
    l_rad                       DOUBLE NULL,  -- v153
    eq_body                     TINYINT NULL,  -- v153
    eq_body_kind                TINYINT NULL,  -- v153
    eq_body_rec                 TINYINT NULL,  -- v153
    eq_body_rec_kind            TINYINT NULL,  -- v153
    eq_rad_suit                 TINYINT NULL,  -- v153
    eq_rad_suit_rec             TINYINT NULL,  -- v153
    eq_mobility                 TINYINT NULL,  -- v153
    eq_dust                     TINYINT NULL,  -- v153
    eq_gas_filter               TINYINT NULL,  -- v153
    eq_co2_scrub                TINYINT NULL,  -- v153
    eq_supply                   TINYINT NULL,  -- v153
    eq_supply_rec               TINYINT NULL,  -- v153
    eq_shelter                  TINYINT NULL,  -- v153
    eq_shelter_rec              TINYINT NULL,  -- v153
    shelter_column_g_cm2        DOUBLE NULL,  -- v153
    energy_flux_w_m2            DOUBLE NULL,  -- v153
    UNIQUE KEY uq_rogue_planets_uid (uid),
    KEY idx_rogue_planets_parent (parent_type, parent_id),
    CONSTRAINT chk_rogue_planets_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    KEY idx_rogue_planets_name (name),  -- v40: name uniqueness lookups
    KEY idx_rogue_planets_placed_name (((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_rogue_planets_descriptor_name (((CASE WHEN mass_bin = 'brown-dwarf' THEN 'brown dwarf' WHEN planet_type = 'g' THEN 'gas giant' ELSE 'terrestrial' END) COLLATE utf8mb4_unicode_ci), name),
    KEY idx_rogue_planets_next_update_due (next_update_due),
    CONSTRAINT chk_rogue_planets_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_rogue_planets_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    KEY idx_rogue_planets_sector_id (sector_id),
    KEY idx_rogue_planets_galactic_radius_pc (galactic_radius_pc),
    KEY idx_rogue_planets_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_rogue_planets_modified_at (modified_at),
    CONSTRAINT fk_rogue_planets_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_rogue_planets_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS interstellar_comets (
    id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id              BIGINT UNSIGNED,
    name                   VARCHAR(255) NOT NULL,
    nucleus_diameter_km    DOUBLE NOT NULL,
    velocity_kms           DOUBLE NOT NULL,
    is_active              TINYINT(1) NOT NULL CHECK (is_active IN (0, 1)),
    composition_summary    TEXT NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    rotation_period_hours       DOUBLE,
    spin_axis_x                 DOUBLE,
    spin_axis_y                 DOUBLE,
    spin_axis_z                 DOUBLE,
    axial_tilt_deg              DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    KEY idx_interstellar_comets_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    uid                   BINARY(12),
    parent_type                 VARCHAR(16) NOT NULL DEFAULT 'free',  -- v140 (DB.73): what it orbits, see the v140 note
    parent_id                   BIGINT UNSIGNED NULL,  -- v140 (DB.73)
    UNIQUE KEY uq_interstellar_comets_uid (uid),
    KEY idx_interstellar_comets_name (name),  -- v178 (PERF.205): the Phenomena table pages by name in index order
    KEY idx_interstellar_comets_placed_name (((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_interstellar_comets_descriptor_name (((CASE WHEN is_active THEN 'active' ELSE 'dormant' END) COLLATE utf8mb4_unicode_ci), name),
    KEY idx_interstellar_comets_parent (parent_type, parent_id),
    CONSTRAINT chk_interstellar_comets_parent_type CHECK (parent_type IN ('star', 'planet', 'system', 'node', 'rogue_planet', 'free')),
    CONSTRAINT chk_interstellar_comets_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_interstellar_comets_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    KEY idx_interstellar_comets_sector_id (sector_id),
    KEY idx_interstellar_comets_next_update_due (next_update_due),
    KEY idx_interstellar_comets_galactic_radius_pc (galactic_radius_pc),
    KEY idx_interstellar_comets_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_interstellar_comets_modified_at (modified_at),
    CONSTRAINT fk_interstellar_comets_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_interstellar_comets_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS interstellar_comet_composition (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    comet_id    BIGINT UNSIGNED NOT NULL,
    position    INT NOT NULL,
    component   VARCHAR(64) NOT NULL,
    CONSTRAINT fk_interstellar_comet_composition_comet
        FOREIGN KEY (comet_id) REFERENCES interstellar_comets(id) ON DELETE CASCADE,
    KEY idx_interstellar_comet_composition_comet_id (comet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_fields (
    id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id             BIGINT UNSIGNED,
    name                  VARCHAR(255) NOT NULL,
    field_class           VARCHAR(4) NOT NULL,
    composition_family    VARCHAR(16) NOT NULL,
    density               VARCHAR(16) NOT NULL CHECK (density IN ('dense', 'sparse', 'typical')),
    radius_ly             DOUBLE NOT NULL,
    composition_summary   TEXT NOT NULL,
    galactic_orbital_period_gy           DOUBLE NOT NULL,
    galactic_orbital_phase_deg           DOUBLE NOT NULL,
    galactic_min_update_interval_years   DOUBLE NOT NULL,
    epoch_unix                  DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due             DOUBLE,
    center_x_pc         DOUBLE,
    center_y_pc         DOUBLE,
    center_z_pc         DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    velocity_x_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_y_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    velocity_z_kms              DOUBLE NULL,  -- v102 (DB.55): galactic-axes velocity, km/s
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    density_g_cm3               DOUBLE,  -- v197 (GEN.1159): the mean bulk density of the members, g/cm3
    ice_mass_fraction           DOUBLE,  -- v197 (GEN.1159): the mean share of the mass of a member that is ice of any kind
    formed_at                   DOUBLE NULL,  -- v102 (DB.55)
    origin_event_id             BIGINT UNSIGNED NULL,  -- v102 (DB.55)
    KEY idx_asteroid_fields_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc  DOUBLE,
    quadrant            VARCHAR(4) CHECK (quadrant IN ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')),
    inside_nebula_id    BIGINT UNSIGNED,
    inside_remnant_id   BIGINT UNSIGNED,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    chondrite_group     VARCHAR(4) NULL,  -- v190 (GEN.475): the nearest chondrite group of the field's mean composition, `none` far from every group, NULL before v190
    uid                   BINARY(12),
    UNIQUE KEY uq_asteroid_fields_uid (uid),
    KEY idx_asteroid_fields_name (name),  -- v178 (PERF.205)
    KEY idx_asteroid_fields_placed_name (((center_x_pc IS NOT NULL)), name),   -- v186 (PERF.211): the Phenomena table's sorts read in index order
    KEY idx_asteroid_fields_descriptor_name (density, name),
    KEY idx_asteroid_fields_radius_name (radius_ly, name),
    CONSTRAINT chk_asteroid_fields_placement CHECK (
        (center_x_pc IS NULL) = (center_y_pc IS NULL) AND
        (center_y_pc IS NULL) = (center_z_pc IS NULL) AND
        (center_z_pc IS NULL) = (galactic_radius_pc IS NULL)
    ),
    CONSTRAINT fk_asteroid_fields_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE SET NULL,
    KEY idx_asteroid_fields_sector_id (sector_id),
    KEY idx_asteroid_fields_next_update_due (next_update_due),
    KEY idx_asteroid_fields_galactic_radius_pc (galactic_radius_pc),
    KEY idx_asteroid_fields_center (center_x_pc, center_y_pc, center_z_pc),
    KEY idx_asteroid_fields_modified_at (modified_at),
    CONSTRAINT fk_asteroid_fields_inside_nebula
        FOREIGN KEY (inside_nebula_id) REFERENCES nebulae(id) ON DELETE SET NULL,
    CONSTRAINT fk_asteroid_fields_inside_remnant
        FOREIGN KEY (inside_remnant_id) REFERENCES supernova_remnants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asteroid_field_composition (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    field_id       BIGINT UNSIGNED NOT NULL,
    position       INT NOT NULL,
    component      VARCHAR(64) NOT NULL,
    concentration  VARCHAR(16) NOT NULL CHECK (concentration IN ('high', 'moderate', 'small', 'trace')),
    CONSTRAINT fk_asteroid_field_composition_field
        FOREIGN KEY (field_id) REFERENCES asteroid_fields(id) ON DELETE CASCADE,
    KEY idx_asteroid_field_composition_field_id (field_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_name_registry (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    base_name         VARCHAR(255) NOT NULL,
    occurrence_count  INT NOT NULL,
    first_sector_id   BIGINT UNSIGNED NOT NULL,
    UNIQUE (base_name),
    CONSTRAINT fk_sector_name_registry_first_sector
        FOREIGN KEY (first_sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_name_registry (
    id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    base_name              VARCHAR(255) NOT NULL,
    occurrence_count       INT NOT NULL,
    first_star_system_id   BIGINT UNSIGNED,
    first_object_table     VARCHAR(32),
    first_object_id        BIGINT UNSIGNED,
    diminutive_index       INT,
    UNIQUE (base_name),
    CONSTRAINT fk_system_name_registry_first_star_system
        FOREIGN KEY (first_star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nearest_systems (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id            BIGINT UNSIGNED NOT NULL,
    object_table         VARCHAR(32) NOT NULL,
    object_id            BIGINT UNSIGNED NOT NULL,
    star_system_id       BIGINT UNSIGNED,
    neighbor_rank        TINYINT NOT NULL,
    neighbor_system_id   BIGINT UNSIGNED NOT NULL,
    distance_pc          DOUBLE NOT NULL,
    UNIQUE KEY uq_nearest_systems_object_rank (object_table, object_id, neighbor_rank),
    KEY idx_nearest_systems_neighbor (neighbor_system_id),
    CONSTRAINT fk_nearest_systems_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    CONSTRAINT fk_nearest_systems_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_nearest_systems_neighbor
        FOREIGN KEY (neighbor_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bright_stars (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    shell_index           INT NOT NULL,
    band_index            INT NOT NULL,
    wedge_index           INT NOT NULL,
    position_x_mpc       DOUBLE NOT NULL,
    position_y_mpc       DOUBLE NOT NULL,
    position_z_mpc       DOUBLE NOT NULL,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(position_x_mpc / 1000.0) < 262144 AND ABS(position_y_mpc / 1000.0) < 262144 AND ABS(position_z_mpc / 1000.0) < 262144, ((((((((((((LEAST(CAST(FLOOR(((position_x_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((position_x_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((position_x_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((position_y_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((position_y_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((position_y_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((position_z_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((position_z_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((position_z_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    KEY idx_bright_stars_cell (cell_key, position_x_mpc, position_y_mpc, position_z_mpc),
    population           VARCHAR(24) NOT NULL,
    star_type            VARCHAR(64) NOT NULL,
    yerkes_class         VARCHAR(16) NOT NULL,
    mass_kg              DOUBLE NOT NULL,
    radius_km            DOUBLE NOT NULL,
    temperature_k        DOUBLE NOT NULL,
    luminosity_w         DOUBLE NOT NULL,
    age_gy               DOUBLE NOT NULL,
    lifespan_gy          DOUBLE,
    initial_mass_sol     DOUBLE NOT NULL,
    phase_end_age_gy     DOUBLE,
    seed                 BIGINT UNSIGNED NOT NULL,
    star_system_id       BIGINT UNSIGNED,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    off_plane            TINYINT AS (ABS(position_z_mpc) >= 250000) VIRTUAL,
    velocity_x_kms       DOUBLE,  -- v93 (GEN.223): the star's point in space, see the header comment
    velocity_y_kms       DOUBLE,
    velocity_z_kms       DOUBLE,
    epoch_unix           DOUBLE,
    next_update_due      DOUBLE,
    member_count         SMALLINT UNSIGNED,  -- v93: companions, see the header comment
    system_mass_solar    DOUBLE,
    metallicity_fe_h     DOUBLE,  -- v95 (GEN.158): [Fe/H] in dex, NULL for a cluster star until GEN.159 and for older rows
    cluster_id           BIGINT UNSIGNED,  -- v127 (DB.61): the cluster this star belongs to, NULL for a field star
    rotation_period_hours DOUBLE,  -- v185 (GEN.846): the spin period in hours, NULL on a row made before v185
    KEY idx_bright_stars_address (shell_index, band_index, wedge_index),
    KEY idx_bright_stars_luminosity (luminosity_w),
    KEY idx_bright_stars_next_update_due (next_update_due),
    KEY idx_bright_stars_population (population, off_plane, luminosity_w),
    CONSTRAINT chk_bright_stars_population CHECK (population IN ('young', 'intermediate', 'old', 'bulge', 'halo', 'cluster', 'satellite', 'nuclear_cluster', 'nuclear_disc', 'satellite_young', 'satellite_intermediate', 'open_cluster_00', 'open_cluster_01', 'open_cluster_02', 'open_cluster_03', 'open_cluster_04', 'open_cluster_05', 'open_cluster_06', 'open_cluster_07', 'open_cluster_08', 'open_cluster_09', 'open_cluster_10', 'open_cluster_11')),
    KEY idx_bright_stars_cluster (cluster_id),
    CONSTRAINT fk_bright_stars_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE SET NULL,
    CONSTRAINT fk_bright_stars_cluster
        FOREIGN KEY (cluster_id) REFERENCES galaxy_components(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_stats (
    shell_index           INT NOT NULL,
    band_index            INT NOT NULL,
    wedge_index           INT NOT NULL,
    bright_level_sol       DOUBLE NOT NULL DEFAULT -1,
    level_before_fill_sol  DOUBLE,
    bright_mass_sol        DOUBLE,
    relative_density       DOUBLE,
    expected_systems       DOUBLE,
    actual_systems         INT,
    actual_stars           INT,
    mean_temperature_k     DOUBLE,
    mean_luminosity_sol    DOUBLE,
    mean_age_gy            DOUBLE,
    total_luminosity_sol   DOUBLE,
    habitable_worlds       INT,   -- v139 (MAP.143): planets and moons in the sector's systems that are Blue or Green overall (PHI-6)
    total_mass_kg          DOUBLE,   -- v168 (DB.108): the mass of the sector's stars, planets, moons, belts, comets and phenomena (not nebulae), NULL when a body has no stored mass
    filled_at              TIMESTAMP(3) NULL,
    updated_at             TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (shell_index, band_index, wedge_index),
    KEY idx_sector_stats_level (bright_level_sol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_paths (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sector_id       BIGINT UNSIGNED NOT NULL,
    object_table    VARCHAR(24) NOT NULL CHECK (object_table IN ('star_systems', 'rogue_planets', 'interstellar_comets')),
    object_id       BIGINT UNSIGNED NOT NULL,
    exited          TINYINT(1) NOT NULL,
    duration_years  DOUBLE NOT NULL,
    computed_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (object_table, object_id),
    KEY idx_sector_paths_sector (sector_id),
    CONSTRAINT fk_sector_paths_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_path_knots (
    id        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    path_id   BIGINT UNSIGNED NOT NULL,
    position  INT NOT NULL,
    t_years   DOUBLE NOT NULL,
    x_pc      DOUBLE NOT NULL,
    y_pc      DOUBLE NOT NULL,
    z_pc      DOUBLE NOT NULL,
    vx_kms    DOUBLE NOT NULL,
    vy_kms    DOUBLE NOT NULL,
    vz_kms    DOUBLE NOT NULL,
    UNIQUE (path_id, position),
    CONSTRAINT fk_sector_path_knots_path
        FOREIGN KEY (path_id) REFERENCES sector_paths(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS generation_runs (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    command              VARCHAR(32) NOT NULL,
    run_seed             BINARY(16),
    galaxy_seed          BINARY(16),
    version_key          CHAR(22) NOT NULL,
    planetgen_version    VARCHAR(32) NOT NULL,
    python_version       VARCHAR(16) NOT NULL,
    platform             VARCHAR(64) NOT NULL,
    started_at           TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    finished_at          TIMESTAMP(3) NULL,
    outcome              VARCHAR(16),
    generator_epoch      SMALLINT UNSIGNED NULL,  -- v131 (OPS.58): the epoch the run's code generated under, NULL before v131
    KEY idx_generation_runs_started_at (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS generation_run_arguments (
    run_id       BIGINT UNSIGNED NOT NULL,
    position     INT NOT NULL,
    value        VARCHAR(1024) NOT NULL,
    PRIMARY KEY (run_id, position),
    CONSTRAINT fk_generation_run_arguments_run FOREIGN KEY (run_id) REFERENCES generation_runs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS scatter_epochs (
    kind             VARCHAR(16) NOT NULL PRIMARY KEY,
    generator_epoch  SMALLINT UNSIGNED NULL,
    run_id           BIGINT UNSIGNED NULL,
    recorded_at      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT chk_scatter_epochs_kind CHECK (kind IN ('mass', 'luminosity', 'band', 'phenomena', 'nebula-field')),
    CONSTRAINT fk_scatter_epochs_run FOREIGN KEY (run_id) REFERENCES generation_runs(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS phenomenon_scatter (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    shell_index           INT NOT NULL,
    band_index            INT NOT NULL,
    wedge_index           INT NOT NULL,
    kind                 VARCHAR(24) NOT NULL,
    subtype              VARCHAR(16),
    position_x_mpc       DOUBLE NOT NULL,
    position_y_mpc       DOUBLE NOT NULL,
    position_z_mpc       DOUBLE NOT NULL,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(position_x_mpc / 1000.0) < 262144 AND ABS(position_y_mpc / 1000.0) < 262144 AND ABS(position_z_mpc / 1000.0) < 262144, ((((((((((((LEAST(CAST(FLOOR(((position_x_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((position_x_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((position_x_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((position_y_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((position_y_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((position_y_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((position_z_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((position_z_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((position_z_mpc / 1000.0) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    KEY idx_phenomenon_scatter_cell (cell_key, position_x_mpc, position_y_mpc, position_z_mpc),
    velocity_x_kms       DOUBLE,
    velocity_y_kms       DOUBLE,
    velocity_z_kms       DOUBLE,
    seed                 BIGINT UNSIGNED NOT NULL,
    built_at             TIMESTAMP NULL,
    epoch_unix           DOUBLE,  -- v69 (GEN.137): when the position holds, see the header comment
    mass_solar           DOUBLE,  -- v80 (MAP.165): see header comment
    map_luminosity_sol   FLOAT,   -- v84 (DB.23): see header comment
    next_update_due      DOUBLE,  -- v93 (GEN.223): see header comment
    member_count         SMALLINT UNSIGNED,  -- v93: companions, see the header comment
    system_mass_solar    DOUBLE,
    KEY idx_phenomenon_scatter_address (shell_index, band_index, wedge_index),
    KEY idx_phenomenon_scatter_next_update_due (next_update_due),
    KEY idx_phenomenon_scatter_class (kind, subtype, mass_solar),  -- v82 (PERF.68): see header comment
    CONSTRAINT chk_phenomenon_scatter_kind CHECK (kind IN (
        'black-hole', 'neutron-star', 'planetary-nebula', 'supernova-remnant', 'hypervelocity-star', 'quasar'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS scatter_members (
    source               TINYINT NOT NULL,
    source_id            BIGINT UNSIGNED NOT NULL,
    member_no            SMALLINT NOT NULL,
    parent_node_no       SMALLINT NOT NULL,
    slot                 SMALLINT NOT NULL,
    kind                 VARCHAR(20) NOT NULL,
    state                VARCHAR(16),
    flags                SMALLINT UNSIGNED,
    offset_x_au          DOUBLE,
    offset_y_au          DOUBLE,
    offset_z_au          DOUBLE,
    velocity_x_kms       DOUBLE,
    velocity_y_kms       DOUBLE,
    velocity_z_kms       DOUBLE,
    decay_age_yr         DOUBLE,
    mass_solar           DOUBLE NOT NULL,
    initial_mass_solar   DOUBLE NOT NULL,
    seed                 BIGINT UNSIGNED NOT NULL,
    epoch_unix                  DOUBLE NULL,  -- v102 (DB.55): when the position and velocity hold
    radius_au                   DOUBLE NULL,  -- v184 (GEN.952): the extent of the member in AU, NULL on a row made before v184
    radius_max_au               DOUBLE NULL,  -- v189 (GEN.1009): the largest radius the member has had, in AU, NULL on a row made before v187
    mass_max_solar              DOUBLE NULL,  -- v189 (GEN.1009): the largest mass the member has had, in solar masses, NULL on a row made before v187
    PRIMARY KEY (source, source_id, member_no),
    CONSTRAINT chk_scatter_members_source CHECK (source IN (1, 2)),
    CONSTRAINT chk_scatter_members_kind CHECK (kind IN (
        'main-sequence', 'giant', 'white-dwarf', 'neutron-star', 'black-hole', 'brown-dwarf',
        'pre-main-sequence', 'protostar', 'stripped-helium', 'thorne-zytkow', 'wolf-rayet'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS scatter_nodes (
    source               TINYINT NOT NULL,
    source_id            BIGINT UNSIGNED NOT NULL,
    node_no              SMALLINT NOT NULL,
    parent_node_no       SMALLINT,
    slot                 SMALLINT,
    mass_solar           DOUBLE NOT NULL,
    separation_km        DOUBLE NOT NULL,
    eccentricity         DOUBLE NOT NULL,
    inclination_deg      DOUBLE NOT NULL,
    ascending_node_deg   DOUBLE NOT NULL,
    arg_periapsis_deg    DOUBLE NOT NULL,
    mean_anomaly_deg     DOUBLE NOT NULL,
    epoch_unix           DOUBLE NOT NULL,
    period_years         DOUBLE NOT NULL,
    kind                 VARCHAR(16) NOT NULL,
    interaction          VARCHAR(20),
    flags                TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (source, source_id, node_no),
    CONSTRAINT chk_scatter_nodes_source CHECK (source IN (1, 2)),
    CONSTRAINT chk_scatter_nodes_kind CHECK (kind IN ('close', 'wide', 'compact', 'group')),
    CONSTRAINT chk_scatter_nodes_interaction CHECK (interaction IS NULL OR interaction IN (
        'detached', 'semi-detached', 'contact', 'accreting', 'post-common-envelope', 'merger-product'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orbit_nodes (
    star_system_id       BIGINT UNSIGNED NOT NULL,
    node_no              SMALLINT NOT NULL,
    parent_node_no       SMALLINT,
    slot                 SMALLINT,
    mass_solar           DOUBLE NOT NULL,
    separation_km        DOUBLE NOT NULL,
    eccentricity         DOUBLE NOT NULL,
    inclination_deg      DOUBLE NOT NULL,
    ascending_node_deg   DOUBLE NOT NULL,
    arg_periapsis_deg    DOUBLE NOT NULL,
    mean_anomaly_deg     DOUBLE NOT NULL,
    epoch_unix           DOUBLE NOT NULL,
    period_years         DOUBLE NOT NULL,
    kind                 VARCHAR(16) NOT NULL,
    interaction          VARCHAR(20),
    flags                TINYINT UNSIGNED NOT NULL DEFAULT 0,
    disk_kind            VARCHAR(16),
    disk_mass_solar      DOUBLE,
    disk_inner_au        DOUBLE,
    disk_outer_au        DOUBLE,
    PRIMARY KEY (star_system_id, node_no),
    CONSTRAINT fk_orbit_nodes_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT chk_orbit_nodes_kind CHECK (kind IN ('close', 'wide', 'compact', 'group')),
    CONSTRAINT chk_orbit_nodes_interaction CHECK (interaction IS NULL OR interaction IN (
        'detached', 'semi-detached', 'contact', 'accreting', 'post-common-envelope', 'merger-product'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS dark_members (
    star_system_id       BIGINT UNSIGNED NOT NULL,
    member_no            SMALLINT NOT NULL,
    parent_node_no       SMALLINT NOT NULL,
    slot                 SMALLINT NOT NULL,
    kind                 VARCHAR(16) NOT NULL,
    mass_solar           DOUBLE NOT NULL,
    radius_au            DOUBLE NULL,
    PRIMARY KEY (star_system_id, member_no),
    CONSTRAINT fk_dark_members_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT chk_dark_members_kind CHECK (kind IN ('brown-dwarf', 'neutron-star', 'black-hole', 'stripped-helium'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_system_counts (
    sector_id      BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    system_count   INT UNSIGNED NOT NULL,
    system_density DOUBLE NULL,         -- v181: systems per cubic milliparsec of the sector, NULL for a sector with no galaxy position
    quadrant       VARCHAR(8) NULL,     -- v181: 'I' to 'IV' as `spherical.sector_quadrant` says, NULL for a sector with no galaxy position
    KEY idx_sector_system_counts_count (system_count, sector_id),
    KEY idx_sector_system_counts_density (system_density, sector_id),
    KEY idx_sector_system_counts_quadrant (quadrant, sector_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_interests (
    star_system_id    BIGINT UNSIGNED NOT NULL,
    reason            VARCHAR(24) NOT NULL,
    n                 SMALLINT UNSIGNED NOT NULL,
    best_score        DOUBLE NULL,
    galaxy_x_pc       DOUBLE NOT NULL,
    galaxy_y_pc       DOUBLE NOT NULL,
    galaxy_z_pc       DOUBLE NOT NULL,
    PRIMARY KEY (star_system_id, reason),
    KEY idx_system_interests_position (galaxy_x_pc, galaxy_y_pc, galaxy_z_pc),
    CONSTRAINT fk_system_interests_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebula_field (
    cell_i        INT NOT NULL,
    cell_j        INT NOT NULL,
    cell_k        INT NOT NULL,
    n             INT UNSIGNED NOT NULL,
    nebula_class  CHAR(1) NOT NULL,
    radius_ly     DOUBLE NOT NULL,
    center_x_pc   DOUBLE NOT NULL,
    center_y_pc   DOUBLE NOT NULL,
    center_z_pc   DOUBLE NOT NULL,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    KEY idx_nebula_field_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    uid           BINARY(12),
    is_stored     TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (cell_i, cell_j, cell_k, n),
    KEY idx_nebula_field_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebula_block_stats (
    m                         SMALLINT UNSIGNED NOT NULL,
    shell_index               INT NOT NULL,
    band_index                INT NOT NULL,
    wedge_index               INT NOT NULL,
    nebula_count              INT UNSIGNED NOT NULL,
    volume_pc3                DOUBLE NOT NULL,
    centroid_x_pc             DOUBLE NULL,
    centroid_y_pc             DOUBLE NULL,
    centroid_z_pc             DOUBLE NULL,
    bound_radius_pc           DOUBLE NULL,
    volume_diffuse_pc3        DOUBLE NOT NULL,
    volume_emission_pc3       DOUBLE NOT NULL,
    volume_reflection_pc3     DOUBLE NOT NULL,
    volume_planetary_pc3      DOUBLE NOT NULL,
    volume_dark_pc3           DOUBLE NOT NULL,
    volume_remnant_pc3        DOUBLE NOT NULL,
    dominant_class            CHAR(1) NULL,
    cover_volume_pc3          DOUBLE NOT NULL,
    cover                     DOUBLE NOT NULL,
    PRIMARY KEY (m, shell_index, band_index, wedge_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebula_block_classes (
    m                         SMALLINT UNSIGNED NOT NULL,
    shell_index               INT NOT NULL,
    band_index                INT NOT NULL,
    wedge_index               INT NOT NULL,
    nebula_class              CHAR(1) NOT NULL,
    volume_pc3                DOUBLE NOT NULL,
    PRIMARY KEY (m, shell_index, band_index, wedge_index, nebula_class)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS nebula_block_state (
    id                        TINYINT UNSIGNED NOT NULL,
    nebulae_through_id        BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orbital_events (
    id                          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    run_id                      BIGINT UNSIGNED NULL,
    kind                        VARCHAR(16) NOT NULL,
    outcome_code                VARCHAR(24) NULL,
    regime                      VARCHAR(24) NULL,
    event_time_unix             DOUBLE NOT NULL,
    detected_time_unix          DOUBLE NOT NULL,
    seed_string                 VARCHAR(255) NOT NULL,
    separation_start_km         DOUBLE NULL,
    separation_impact_km        DOUBLE NULL,
    impact_parameter_km         DOUBLE NULL,
    critical_impact_parameter_km DOUBLE NULL,
    v_inf_kms                   DOUBLE NULL,
    v_esc_kms                   DOUBLE NULL,
    v_imp_kms                   DOUBLE NULL,
    q_r_j_per_kg                DOUBLE NULL,
    q_star_rd_j_per_kg          DOUBLE NULL,
    erosion_x                   DOUBLE NULL,
    interacting_mass_fraction   DOUBLE NULL,
    catastrophic_velocity_kms   DOUBLE NULL,
    window_s                    DOUBLE NULL,
    window_capped               TINYINT NOT NULL DEFAULT 0,
    focusing_radius_used        TINYINT NOT NULL DEFAULT 0,
    mass_error                  DOUBLE NULL,
    momentum_error              DOUBLE NULL,
    conservation_tolerance      DOUBLE NULL,
    impact_energy_j             DOUBLE NULL,
    heat_share                  DOUBLE NULL,
    lost_mass_kg                DOUBLE NULL,
    merged_mass_kg              DOUBLE NULL,
    new_radius_km               DOUBLE NULL,
    spin_breakup_ratio          DOUBLE NULL,
    deuterium_limit_mj          DOUBLE NULL,
    hydrogen_limit_sol          DOUBLE NULL,
    borderline                  TINYINT NOT NULL DEFAULT 0,
    containing_uid              BINARY(12) NULL,
    influence_body_count        INT UNSIGNED NULL,
    sectors_dirtied             INT UNSIGNED NULL,
    suppressed_duplicates       INT UNSIGNED NOT NULL DEFAULT 0,
    already_overlapping         TINYINT NOT NULL DEFAULT 0,
    numeric_warning             TINYINT NOT NULL DEFAULT 0,
    flags                       VARCHAR(255) NOT NULL DEFAULT '',
    recorded_at                 TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    KEY idx_orbital_events_time (event_time_unix, id),
    KEY idx_orbital_events_kind (kind, event_time_unix, id),
    KEY idx_orbital_events_run (run_id, id),
    CONSTRAINT chk_orbital_events_kind CHECK (kind IN
        ('collision', 'merger', 'split', 'ejection', 'capture', 'unbind', 'warning')),
    CONSTRAINT chk_orbital_events_window_capped CHECK (window_capped IN (0, 1)),
    CONSTRAINT chk_orbital_events_focusing CHECK (focusing_radius_used IN (0, 1)),
    CONSTRAINT chk_orbital_events_borderline CHECK (borderline IN (0, 1)),
    CONSTRAINT chk_orbital_events_overlapping CHECK (already_overlapping IN (0, 1)),
    CONSTRAINT chk_orbital_events_numeric_warning CHECK (numeric_warning IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orbital_event_bodies (
    event_id                    BIGINT UNSIGNED NOT NULL,
    role                        VARCHAR(12) NOT NULL,
    ordinal                     SMALLINT UNSIGNED NOT NULL,
    uid                         BINARY(12) NOT NULL,
    object_kind                 VARCHAR(24) NOT NULL,
    fate                        VARCHAR(12) NULL,
    name                        VARCHAR(255) NULL,
    object_class                VARCHAR(64) NULL,
    mass_kg                     DOUBLE NULL,
    radius_km                   DOUBLE NULL,
    composition                 VARCHAR(64) NULL,
    sector_id                   BIGINT UNSIGNED NULL,
    x_pc                        DOUBLE NULL,
    y_pc                        DOUBLE NULL,
    z_pc                        DOUBLE NULL,
    vx_kms                      DOUBLE NULL,
    vy_kms                      DOUBLE NULL,
    vz_kms                      DOUBLE NULL,
    admin_edited                TINYINT NOT NULL DEFAULT 0,
    note                        VARCHAR(255) NULL,
    PRIMARY KEY (event_id, role, ordinal),
    KEY idx_orbital_event_bodies_uid (uid, event_id),
    CONSTRAINT fk_orbital_event_bodies_event FOREIGN KEY (event_id) REFERENCES orbital_events(id) ON DELETE CASCADE,
    CONSTRAINT chk_orbital_event_bodies_role CHECK (role IN ('participant', 'product')),
    CONSTRAINT chk_orbital_event_bodies_fate CHECK (fate IS NULL OR fate IN ('destroyed', 'survived', 'absorbed', 'created')),
    CONSTRAINT chk_orbital_event_bodies_edited CHECK (admin_edited IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS object_timing_stats (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    run_id        BIGINT UNSIGNED NOT NULL,
    sector_id     BIGINT UNSIGNED NULL,
    kind          VARCHAR(24) NOT NULL,
    object_count  INT UNSIGNED NOT NULL,
    total_us      BIGINT UNSIGNED NOT NULL,
    min_us        BIGINT UNSIGNED NOT NULL,
    max_us        BIGINT UNSIGNED NOT NULL,
    histogram     VARCHAR(255) NOT NULL,
    KEY idx_object_timing_stats_run (run_id, kind),
    KEY idx_object_timing_stats_sector (sector_id),
    CONSTRAINT fk_object_timing_stats_run FOREIGN KEY (run_id) REFERENCES generation_runs(id) ON DELETE CASCADE,
    CONSTRAINT fk_object_timing_stats_sector FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS object_timing_samples (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    run_id     BIGINT UNSIGNED NOT NULL,
    sector_id  BIGINT UNSIGNED NULL,
    kind       VARCHAR(24) NOT NULL,
    ordinal    INT UNSIGNED NOT NULL,
    own_us     BIGINT UNSIGNED NOT NULL,
    total_us   BIGINT UNSIGNED NOT NULL,
    sampled    TINYINT(1) NOT NULL,
    KEY idx_object_timing_samples_run (run_id, kind),
    KEY idx_object_timing_samples_sector (sector_id),
    CONSTRAINT fk_object_timing_samples_run FOREIGN KEY (run_id) REFERENCES generation_runs(id) ON DELETE CASCADE,
    CONSTRAINT fk_object_timing_samples_sector FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS phenomenon_scatter_classes (
    kind     VARCHAR(24) NOT NULL,
    subtype  VARCHAR(16) NOT NULL DEFAULT '',
    placed   BIGINT UNSIGNED NOT NULL DEFAULT 0,
    built    BIGINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (kind, subtype)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS id_blocks (
    table_name  VARCHAR(64) NOT NULL PRIMARY KEY,
    next_id     BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS id_counters (
    kind        VARCHAR(8) NOT NULL,
    scope       VARBINARY(16) NOT NULL,
    next_value  BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (kind, scope)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS species (
    id                       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                     VARCHAR(255) NOT NULL,
    homeworld_planet_id      BIGINT UNSIGNED NOT NULL,
    star_system_id           BIGINT UNSIGNED NOT NULL,
    life_class               VARCHAR(2),
    life_stage               VARCHAR(32) NOT NULL,
    build                    VARCHAR(16) NOT NULL,
    climate                  VARCHAR(16) NOT NULL,
    size                     VARCHAR(16) NOT NULL,
    civilization_age_years   DOUBLE,
    era                      VARCHAR(16),
    spacefaring              TINYINT(1) NOT NULL DEFAULT 0 CHECK (spacefaring IN (0, 1)),
    energy_index             TINYINT UNSIGNED CHECK (energy_index BETWEEN 0 AND 7),
    materials_index          TINYINT UNSIGNED CHECK (materials_index BETWEEN 0 AND 7),
    information_index        TINYINT UNSIGNED CHECK (information_index BETWEEN 0 AND 7),
    medical_index            TINYINT UNSIGNED CHECK (medical_index BETWEEN 0 AND 7),
    propulsion_index         TINYINT UNSIGNED CHECK (propulsion_index BETWEEN 0 AND 7),
    defense_index            TINYINT UNSIGNED CHECK (defense_index BETWEEN 0 AND 7),
    tech_level               DECIMAL(3,2),
    tech_source              VARCHAR(16) CHECK (tech_source IN ('generated', 'admin')),
    generator_epoch          SMALLINT UNSIGNED NULL,  -- v164 (GEN.764): the epoch the population pass made this species under
    created_at               TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_species_name (name),
    UNIQUE KEY uq_species_homeworld (homeworld_planet_id),
    KEY idx_species_system (star_system_id),
    KEY idx_species_spacefaring_name (spacefaring, name),     -- v177 (PERF.205): the Species table's sorts read in index order
    KEY idx_species_tech_level_name (tech_level, name),       -- (the tech level search by range uses the leading column)
    KEY idx_species_era_name (era, name),
    CONSTRAINT chk_species_life_stage CHECK (life_stage IN ('multicellularity', 'technological_civilization')),
    CONSTRAINT fk_species_planet
        FOREIGN KEY (homeworld_planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    CONSTRAINT fk_species_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS polities (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(255) NOT NULL,
    species_id          BIGINT UNSIGNED NOT NULL,
    capital_system_id   BIGINT UNSIGNED NOT NULL,
    government          VARCHAR(32) NOT NULL,
    color               CHAR(7) NOT NULL,
    reach_ly            DOUBLE NOT NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_polities_name (name),
    UNIQUE KEY uq_polities_species (species_id),
    KEY idx_polities_capital (capital_system_id),
    CONSTRAINT fk_polities_species
        FOREIGN KEY (species_id) REFERENCES species(id) ON DELETE CASCADE,
    CONSTRAINT fk_polities_capital
        FOREIGN KEY (capital_system_id) REFERENCES star_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS facility_types (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(255) NOT NULL,
    kind                 VARCHAR(16) NOT NULL,
    icon                 VARCHAR(64),
    description          TEXT,
    sort_order           INT NOT NULL DEFAULT 0,
    active               TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY uq_facility_types_name (name),
    KEY idx_facility_types_kind (kind),
    CONSTRAINT chk_facility_types_kind CHECK (kind IN ('colony', 'outpost', 'mining-colony', 'station', 'starbase')),
    CONSTRAINT chk_facility_types_active CHECK (active IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS facility_type_fields (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    type_id              BIGINT UNSIGNED NOT NULL,
    `key`                VARCHAR(32) NOT NULL,
    label                VARCHAR(255) NOT NULL,
    datatype             VARCHAR(8) NOT NULL,
    unit                 VARCHAR(32),
    required             TINYINT(1) NOT NULL DEFAULT 0,
    min_value            DOUBLE,
    max_value            DOUBLE,
    choices              TEXT,
    default_text         VARCHAR(255),
    sort_order           INT NOT NULL DEFAULT 0,
    UNIQUE KEY uq_facility_type_fields_key (type_id, `key`),
    CONSTRAINT chk_facility_type_fields_datatype CHECK (datatype IN ('int', 'decimal', 'text', 'bool', 'choice')),
    CONSTRAINT chk_facility_type_fields_required CHECK (required IN (0, 1)),
    CONSTRAINT fk_facility_type_fields_type
        FOREIGN KEY (type_id) REFERENCES facility_types(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS facilities (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(255) NOT NULL,
    kind                 VARCHAR(16) NOT NULL,
    placement            VARCHAR(16) NOT NULL,
    host_type            VARCHAR(16) NOT NULL,
    star_system_id       BIGINT UNSIGNED,
    star_id              BIGINT UNSIGNED,
    planet_id            BIGINT UNSIGNED,
    moon_id              BIGINT UNSIGNED,
    asteroid_belt_id     BIGINT UNSIGNED,
    asteroid_field_id    BIGINT UNSIGNED,
    sector_id            BIGINT UNSIGNED,
    center_x_pc          DOUBLE,
    center_y_pc          DOUBLE,
    center_z_pc          DOUBLE,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    mass_kg                     DOUBLE NULL,  -- v102 (DB.55): point mass, a stated zero where the mass is not known
    KEY idx_facilities_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    galactic_radius_pc   DOUBLE,
    velocity_x_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms       DOUBLE NOT NULL DEFAULT 0,
    orbit_distance_km    DOUBLE,
    orbit_period_years   DOUBLE,
    orbital_speed_kms    DOUBLE,
    orbit_phase_deg      DOUBLE,
    epoch_unix           DOUBLE,  -- v66 (GEN.106), see header comment
    next_update_due      DOUBLE,
    description          TEXT,
    uid                  BINARY(12),  -- v78 (DB.20), see header comment
    type_id              BIGINT UNSIGNED,
    affiliation_polity_id BIGINT UNSIGNED,
    affiliation_name     VARCHAR(255),
    rating_crime         TINYINT UNSIGNED,
    rating_housing       TINYINT UNSIGNED,
    rating_resources     TINYINT UNSIGNED,
    rating_maintenance   TINYINT UNSIGNED,
    rating_health        TINYINT UNSIGNED,
    ratings_source       VARCHAR(16),
    ratings_note         TEXT,
    ratings_set_at       TIMESTAMP NULL,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    KEY idx_facilities_type (type_id),
    KEY idx_facilities_affiliation (affiliation_polity_id),
    KEY idx_facilities_rating_crime (rating_crime),
    KEY idx_facilities_rating_housing (rating_housing),
    KEY idx_facilities_rating_resources (rating_resources),
    KEY idx_facilities_rating_maintenance (rating_maintenance),
    KEY idx_facilities_rating_health (rating_health),
    KEY idx_facilities_star_system (star_system_id),
    KEY idx_facilities_next_update_due (next_update_due),
    KEY idx_facilities_sector (sector_id),
    KEY idx_facilities_name (name),
    UNIQUE KEY uq_facilities_uid (uid),
    CONSTRAINT chk_facilities_kind CHECK (kind IN ('colony', 'outpost', 'mining-colony', 'station', 'starbase')),
    CONSTRAINT chk_facilities_placement CHECK (placement IN ('terrestrial', 'orbital', 'asteroid', 'standalone')),
    CONSTRAINT chk_facilities_rating_crime CHECK (rating_crime BETWEEN 1 AND 3),
    CONSTRAINT chk_facilities_rating_housing CHECK (rating_housing BETWEEN 1 AND 3),
    CONSTRAINT chk_facilities_rating_resources CHECK (rating_resources BETWEEN 1 AND 3),
    CONSTRAINT chk_facilities_rating_maintenance CHECK (rating_maintenance BETWEEN 1 AND 3),
    CONSTRAINT chk_facilities_rating_health CHECK (rating_health BETWEEN 1 AND 3),
    CONSTRAINT fk_facilities_star_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_star
        FOREIGN KEY (star_id) REFERENCES stars(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_planet
        FOREIGN KEY (planet_id) REFERENCES planets(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_moon
        FOREIGN KEY (moon_id) REFERENCES moons(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_asteroid_belt
        FOREIGN KEY (asteroid_belt_id) REFERENCES asteroid_belts(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_asteroid_field
        FOREIGN KEY (asteroid_field_id) REFERENCES asteroid_fields(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_sector
        FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    CONSTRAINT fk_facilities_type
        FOREIGN KEY (type_id) REFERENCES facility_types(id) ON DELETE RESTRICT,
    CONSTRAINT fk_facilities_affiliation_polity
        FOREIGN KEY (affiliation_polity_id) REFERENCES polities(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS facility_field_values (
    facility_id          BIGINT UNSIGNED NOT NULL,
    field_id             BIGINT UNSIGNED NOT NULL,
    value_int            BIGINT,
    value_dec            DOUBLE,
    value_text           VARCHAR(255),
    value_bool           TINYINT(1),
    PRIMARY KEY (facility_id, field_id),
    KEY idx_facility_field_values_field (field_id),
    CONSTRAINT fk_facility_field_values_facility
        FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    CONSTRAINT fk_facility_field_values_field
        FOREIGN KEY (field_id) REFERENCES facility_type_fields(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_owners (
    star_system_id   BIGINT UNSIGNED PRIMARY KEY,
    polity_id        BIGINT UNSIGNED NOT NULL,
    distance_ly      DOUBLE NOT NULL,
    KEY idx_system_owners_polity (polity_id),
    CONSTRAINT fk_system_owners_system
        FOREIGN KEY (star_system_id) REFERENCES star_systems(id) ON DELETE CASCADE,
    CONSTRAINT fk_system_owners_polity
        FOREIGN KEY (polity_id) REFERENCES polities(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS population_state (
    id                     TINYINT UNSIGNED PRIMARY KEY,
    scanned_planet_id      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    CHECK (id = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_components (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kind                 VARCHAR(12) NOT NULL,
    name                 VARCHAR(255) NULL,  -- v127 (DB.61): NULL for a cluster nobody has named, the unique key is over the named rows
    catalogue_id         VARCHAR(40),
    source               VARCHAR(12) NOT NULL,
    parent_component_id  BIGINT UNSIGNED,
    center_x_pc          DOUBLE NOT NULL,
    center_y_pc          DOUBLE NOT NULL,
    center_z_pc          DOUBLE NOT NULL,
    cell_key             BIGINT UNSIGNED GENERATED ALWAYS AS (IF(ABS(center_x_pc) < 262144 AND ABS(center_y_pc) < 262144 AND ABS(center_z_pc) < 262144, ((((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_x_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 2) | ((((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_y_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)) << 1) | (((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 0) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 0) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 7) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 21) | ((((((((((LEAST(CAST(FLOOR(((center_z_pc) + 262144) / 0.25) AS UNSIGNED), 2097151)) >> 14) & 127) * 257) & 28687) * 17) & 274627) * 5) & 299593) << 42)), NULL)) STORED,
    KEY idx_galaxy_components_cell (cell_key, center_x_pc, center_y_pc, center_z_pc),
    velocity_x_kms       DOUBLE NOT NULL,
    velocity_y_kms       DOUBLE NOT NULL,
    velocity_z_kms       DOUBLE NOT NULL,
    epoch_unix           DOUBLE NOT NULL,
    mass_solar           DOUBLE NOT NULL,
    half_mass_radius_pc  DOUBLE NOT NULL,
    profile              VARCHAR(12) NOT NULL,
    king_w0              DOUBLE,
    tidal_radius_pc      DOUBLE,
    age_gy               DOUBLE NOT NULL,
    metallicity_fe_h     DOUBLE NOT NULL,
    core_collapsed       TINYINT(1) NOT NULL DEFAULT 0,
    seed                 BIGINT UNSIGNED NOT NULL,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_galaxy_components_name (kind, name),
    KEY idx_galaxy_components_parent (parent_component_id),
    CONSTRAINT fk_galaxy_components_parent
        FOREIGN KEY (parent_component_id) REFERENCES galaxy_components(id) ON DELETE SET NULL,
    CONSTRAINT chk_galaxy_components_kind CHECK (kind IN ('cluster', 'satellite', 'stream')),
    CONSTRAINT chk_galaxy_components_source CHECK (source IN ('catalogue', 'generated')),
    CONSTRAINT chk_galaxy_components_profile CHECK (profile IN ('king', 'exponential', 'plummer')),
    CONSTRAINT chk_galaxy_components_core_collapsed CHECK (core_collapsed IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS object_index (
    kind            VARCHAR(24) NOT NULL,
    uid             BINARY(12) NOT NULL,
    source_id       BIGINT UNSIGNED NOT NULL,
    name            VARCHAR(255) NOT NULL,
    sector_id       BIGINT UNSIGNED NULL,
    system_id       BIGINT UNSIGNED NULL,
    parent_uid      BINARY(12) NULL,
    object_class    VARCHAR(64) NULL,
    mass_kg         DOUBLE NULL,
    radius_km       DOUBLE NULL,
    placed          TINYINT(1) NOT NULL DEFAULT 1,
    indexed_at      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (kind, uid),
    KEY idx_object_index_source (kind, source_id),
    KEY idx_object_index_name (kind, name, uid),
    KEY idx_object_index_class (kind, object_class, name, uid),
    KEY idx_object_index_mass (kind, mass_kg, uid),
    KEY idx_object_index_radius (kind, radius_km, uid),
    KEY idx_object_index_sector (sector_id, kind, name, uid),
    KEY idx_object_index_system (system_id, kind, uid),
    FULLTEXT KEY ft_object_index_name (name),
    CONSTRAINT chk_object_index_placed CHECK (placed IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS galaxy_containers (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid           BINARY(12) NOT NULL,
    kind          VARCHAR(16) NOT NULL,
    name          VARCHAR(255) NULL,
    component_id  BIGINT UNSIGNED NULL,
    bubble_col      INT NULL,
    bubble_row      INT NULL,
    bubble_n      SMALLINT UNSIGNED NULL,
    center_x_pc   DOUBLE NOT NULL,
    center_y_pc   DOUBLE NOT NULL,
    center_z_pc   DOUBLE NOT NULL,
    extent_pc     DOUBLE NOT NULL,
    shell_index   INT NOT NULL,
    band_index    INT NOT NULL,
    wedge_index   INT NOT NULL,
    created_at    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    UNIQUE KEY uq_galaxy_containers_uid (uid),
    UNIQUE KEY uq_galaxy_containers_bubble (bubble_col, bubble_row, bubble_n),
    KEY idx_galaxy_containers_kind_x (kind, center_x_pc),
    KEY idx_galaxy_containers_birth (shell_index, band_index, wedge_index),
    KEY idx_galaxy_containers_component (component_id),
    CONSTRAINT fk_galaxy_containers_component FOREIGN KEY (component_id) REFERENCES galaxy_components(id) ON DELETE CASCADE,
    CONSTRAINT chk_galaxy_containers_kind CHECK (kind IN ('globular_cluster', 'superbubble')),
    CONSTRAINT chk_galaxy_containers_extent CHECK (extent_pc >= 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS vessels (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid                  BINARY(12) NOT NULL,
    kind                 VARCHAR(8) NOT NULL,
    name                 VARCHAR(255) NOT NULL,
    origin               VARCHAR(12) NOT NULL,
    owner_id             BIGINT UNSIGNED NULL,
    owner_name           VARCHAR(255) NULL,
    center_x_pc          DOUBLE NULL,
    center_y_pc          DOUBLE NULL,
    center_z_pc          DOUBLE NULL,
    mass_kg              DOUBLE NULL,
    velocity_x_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_y_kms       DOUBLE NOT NULL DEFAULT 0,
    velocity_z_kms       DOUBLE NOT NULL DEFAULT 0,
    epoch_unix           DOUBLE NULL,
    course               JSON NULL,
    seed                 BIGINT UNSIGNED NULL,
    version_key          CHAR(22) NULL,
    created_at           TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    UNIQUE KEY uq_vessels_uid (uid),
    KEY idx_vessels_owner (owner_id, id),
    CONSTRAINT chk_vessels_kind CHECK (kind IN ('ship', 'station')),
    CONSTRAINT chk_vessels_origin CHECK (origin IN ('generated', 'user'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS constellations (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    system_uid           BINARY(12) NOT NULL,
    constellation_index  SMALLINT UNSIGNED NOT NULL,
    name_id              BINARY(12) NULL,
    members              JSON NOT NULL,
    edges                JSON NOT NULL,
    seed                 BIGINT UNSIGNED NOT NULL,
    version_key          CHAR(22) NOT NULL,
    created_at           TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    UNIQUE KEY uq_constellations_system_index (system_uid, constellation_index),
    KEY idx_constellations_name (name_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS request_comments (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plan_id       BIGINT UNSIGNED NOT NULL,
    author_id     BIGINT UNSIGNED NULL,
    author_name   VARCHAR(255) NOT NULL,
    author_role   VARCHAR(16) NOT NULL,
    body          TEXT NOT NULL,
    created_at    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    KEY idx_request_comments_plan (plan_id, id),
    CONSTRAINT fk_request_comments_plan FOREIGN KEY (plan_id) REFERENCES change_plans(id) ON DELETE CASCADE,
    CONSTRAINT chk_request_comments_author_role CHECK (author_role IN ('user', 'moderator', 'admin'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS request_notifications (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plan_id       BIGINT UNSIGNED NOT NULL,
    recipient_id  BIGINT UNSIGNED NOT NULL,
    kind          VARCHAR(32) NOT NULL,
    created_at    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    sent_at       TIMESTAMP(3) NULL,
    KEY idx_request_notifications_recipient (recipient_id, sent_at, id),
    KEY idx_request_notifications_plan (plan_id, id),
    CONSTRAINT fk_request_notifications_plan FOREIGN KEY (plan_id) REFERENCES change_plans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS region_density_overrides (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    shape         VARCHAR(16) NOT NULL,
    params        JSON NOT NULL,
    multiplier    DECIMAL(10,4) NOT NULL,
    set_by_id     BIGINT UNSIGNED NULL,
    set_by_name   VARCHAR(255) NOT NULL,
    set_at        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    reason        VARCHAR(500) NULL,
    undone_at     TIMESTAMP(3) NULL,
    KEY idx_region_density_overrides_active (undone_at, id),
    CONSTRAINT chk_region_density_overrides_shape CHECK (shape IN ('sphere', 'box', 'shell', 'band', 'wedge', 'sectors')),
    CONSTRAINT chk_region_density_overrides_multiplier CHECK (multiplier >= 0.0001)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS object_locks (
    object_uid       BINARY(12) NOT NULL,
    aspect           VARCHAR(64) NOT NULL DEFAULT '*',
    locked_by_id     BIGINT UNSIGNED NULL,
    locked_by_name   VARCHAR(255) NOT NULL,
    locked_at        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    reason           VARCHAR(500) NULL,
    PRIMARY KEY (object_uid, aspect),
    KEY idx_object_locks_locked_at (locked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS change_plans (
    id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    requester_id     BIGINT UNSIGNED NULL,
    requester_name   VARCHAR(255) NOT NULL,
    requester_role   VARCHAR(16) NOT NULL,
    request_text     TEXT NULL,
    state            VARCHAR(16) NOT NULL DEFAULT 'draft',
    approver_role    VARCHAR(16) NULL,
    decided_by_id    BIGINT UNSIGNED NULL,
    decided_by_name  VARCHAR(255) NULL,
    decided_at       TIMESTAMP(3) NULL,
    decision_note    TEXT NULL,
    apply_job_id     BIGINT UNSIGNED NULL,
    created_at       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    KEY idx_change_plans_state (state, id),
    KEY idx_change_plans_requester (requester_id, id),
    CONSTRAINT chk_change_plans_state CHECK (state IN
        ('draft', 'requested', 'proposed', 'approved', 'applied', 'undone', 'stale', 'rejected', 'withdrawn')),
    CONSTRAINT chk_change_plans_requester_role CHECK (requester_role IN ('user', 'moderator', 'admin')),
    CONSTRAINT chk_change_plans_approver_role CHECK (approver_role IS NULL OR approver_role IN ('moderator', 'admin'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS change_plan_ops (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plan_id     BIGINT UNSIGNED NOT NULL,
    op_order    INT NOT NULL,
    kind        VARCHAR(48) NOT NULL,
    target_uid  BINARY(12) NULL,
    before_json JSON NULL,
    after_json  JSON NULL,
    status      VARCHAR(16) NOT NULL DEFAULT 'pending',
    UNIQUE KEY uq_change_plan_ops_order (plan_id, op_order),
    KEY idx_change_plan_ops_target (target_uid),
    CONSTRAINT fk_change_plan_ops_plan FOREIGN KEY (plan_id) REFERENCES change_plans(id) ON DELETE CASCADE,
    CONSTRAINT chk_change_plan_ops_status CHECK (status IN ('pending', 'applied', 'undone', 'skipped', 'failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS edit_journal (
    id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plan_id          BIGINT UNSIGNED NOT NULL,
    op_id            BIGINT UNSIGNED NULL,
    object_uid       BINARY(12) NOT NULL,
    sector_id        BIGINT UNSIGNED NULL,
    aspect           VARCHAR(64) NOT NULL,
    before_json      JSON NULL,
    after_json       JSON NULL,
    generator_epoch  SMALLINT UNSIGNED NOT NULL,
    applied_at       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    KEY idx_edit_journal_object (object_uid, id),
    KEY idx_edit_journal_sector (sector_id, id),
    KEY idx_edit_journal_plan (plan_id, id),
    CONSTRAINT fk_edit_journal_plan FOREIGN KEY (plan_id) REFERENCES change_plans(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sector_tree_nodes (
    level         TINYINT UNSIGNED NOT NULL,
    shell_index   INT NOT NULL,
    band_index    INT NOT NULL DEFAULT 0,
    digest        BINARY(32) NULL,
    child_count   INT UNSIGNED NOT NULL DEFAULT 0,
    dirty         TINYINT(1) NOT NULL DEFAULT 1,
    updated_at    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (level, shell_index, band_index),
    KEY idx_sector_tree_nodes_dirty (dirty, level),
    CONSTRAINT chk_sector_tree_nodes_level CHECK (level IN (1, 2)),
    CONSTRAINT chk_sector_tree_nodes_shell_band CHECK (level = 1 OR band_index = 0),
    CONSTRAINT chk_sector_tree_nodes_dirty CHECK (dirty IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS species_limit_values (
    species_id   BIGINT UNSIGNED NOT NULL,
    limit_name   VARCHAR(48) NOT NULL,
    value        DOUBLE NOT NULL,
    PRIMARY KEY (species_id, limit_name),
    CONSTRAINT fk_species_limit_values_species
        FOREIGN KEY (species_id) REFERENCES species(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE OR REPLACE VIEW sector_objects AS
    SELECT
        'star'                          AS object_type,
        s.id                            AS object_id,
        s.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        s.name                          AS name,
        s.star_type                     AS summary,
        NULL                            AS orbital_index
    FROM stars s
    JOIN star_systems ss ON ss.id = s.star_system_id
    UNION ALL
    SELECT
        'planet'                        AS object_type,
        p.id                            AS object_id,
        p.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        p.name                          AS name,
        COALESCE(p.planet_class, p.body_type) AS summary,
        p.orbital_index                 AS orbital_index
    FROM planets p
    JOIN star_systems ss ON ss.id = p.star_system_id
    UNION ALL
    SELECT
        'moon'                          AS object_type,
        m.id                            AS object_id,
        m.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        m.name                          AS name,
        COALESCE(m.planet_class, m.body_type) AS summary,
        m.orbital_index                 AS orbital_index
    FROM moons m
    JOIN star_systems ss ON ss.id = m.star_system_id
    UNION ALL
    SELECT
        'asteroid_belt'                 AS object_type,
        ab.id                           AS object_id,
        ab.star_system_id               AS star_system_id,
        ss.sector_id                    AS sector_id,
        'Asteroid Belt'                 AS name,
        ab.density                      AS summary,
        ab.orbital_index                AS orbital_index
    FROM asteroid_belts ab
    JOIN star_systems ss ON ss.id = ab.star_system_id
    UNION ALL
    SELECT
        'comet'                         AS object_type,
        c.id                            AS object_id,
        c.star_system_id                AS star_system_id,
        ss.sector_id                    AS sector_id,
        c.name                          AS name,
        c.orbit_type                    AS summary,
        NULL                            AS orbital_index
    FROM comets c
    JOIN star_systems ss ON ss.id = c.star_system_id;
SET FOREIGN_KEY_CHECKS = 1;
